// src-tauri/src/commands.rs
use crate::kml::processor::extract_geometries_from_zip;
use crate::spatial_db::{
    AnalyticsResult, DatabaseInfo, KmlRecord, LinkRecord, PathResult, SiteRecord, SpatialDatabase,
};
use log::{debug, error, info, warn};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::fs;
use std::sync::Arc;
use tauri::{AppHandle, Manager, State};

pub type DatabaseManager = std::sync::Mutex<HashMap<String, SpatialDatabase>>;

// pub type DatabaseManager = Arc<Mutex<HashMap<String, SpatialDatabase>>>;

#[derive(Debug, Serialize, Deserialize)]
pub struct CreateDatabaseRequest {
    pub name: String,
    pub description: Option<String>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct ImportDataRequest {
    pub database_name: String,
    pub sites: Vec<SiteRecord>,
    pub links: Vec<LinkRecord>,
    pub kmz_base64: Option<String>, // Base64 encoded ZIP/KMZ
}

#[tauri::command]
pub fn create_database(
    request: CreateDatabaseRequest,
    app_handle: AppHandle,
    databases: State<'_, DatabaseManager>,
) -> Result<DatabaseInfo, String> {
    println!("🗃️ Creating database: {}", request.name);

    let app_data_dir = app_handle.path().app_data_dir().map_err(|e| {
        error!("Failed to get app data directory: {}", e);
        format!("Failed to get app data directory: {}", e)
    })?;

    std::fs::create_dir_all(&app_data_dir).map_err(|e| {
        error!("Failed to create app data directory: {}", e);
        format!("Failed to create app data directory: {}", e)
    })?;

    let db_path = app_data_dir.join(format!("{}.sqlite", request.name));
    debug!("Creating database at path: {:?}", db_path);

    // Check if database already exists
    if db_path.exists() {
        warn!("Database {} already exists, will overwrite", request.name);
    }

    let db =
        SpatialDatabase::new(&db_path, request.name.clone(), Some(&app_handle)).map_err(|e| {
            error!("Failed to create database {}: {}", request.name, e);
            format!("Failed to create database: {}", e)
        })?;

    let info = db.get_database_info();

    let mut manager = databases.lock().unwrap();
    manager.insert(request.name.clone(), db);

    println!("✅ Database {} created successfully", request.name);
    Ok(info)
}

#[tauri::command]
pub fn list_databases(
    app_handle: AppHandle,
    databases: State<'_, DatabaseManager>,
) -> Result<Vec<String>, String> {
    println!("📋 Listing all databases");

    let app_data_dir = app_handle.path().app_data_dir().map_err(|e| {
        error!("Failed to get app data directory: {}", e);
        format!("Failed to get app data directory: {}", e)
    })?;

    let mut db_names = Vec::new();

    // Scan filesystem for .sqlite files
    if app_data_dir.exists() {
        match fs::read_dir(&app_data_dir) {
            Ok(entries) => {
                for entry in entries {
                    if let Ok(entry) = entry {
                        let path = entry.path();
                        if path.is_file()
                            && path.extension().and_then(|s| s.to_str()) == Some("sqlite")
                        {
                            if let Some(name) = path.file_stem().and_then(|s| s.to_str()) {
                                db_names.push(name.to_string());
                                debug!("Found database: {}", name);
                            }
                        }
                    }
                }
            }
            Err(e) => {
                error!("Failed to read app data directory: {}", e);
                return Err(format!("Failed to read app data directory: {}", e));
            }
        }
    }

    // Also add any in-memory databases
    let manager = databases.lock().unwrap();
    for key in manager.keys() {
        if !db_names.contains(key) {
            db_names.push(key.clone());
        }
    }

    db_names.sort();
    println!("📊 Found {} databases: {:?}", db_names.len(), db_names);
    Ok(db_names)
}

#[tauri::command]
pub fn delete_database(
    db_name: String,
    app_handle: AppHandle,
    databases: State<'_, DatabaseManager>,
) -> Result<String, String> {
    println!("🗑️ Deleting database: {}", db_name);

    // Remove from memory
    let mut manager = databases.lock().unwrap();
    manager.remove(&db_name);

    // Delete file from filesystem
    let app_data_dir = app_handle.path().app_data_dir().map_err(|e| {
        error!("Failed to get app data directory: {}", e);
        format!("Failed to get app data directory: {}", e)
    })?;

    let db_path = app_data_dir.join(format!("{}.sqlite", db_name));

    if db_path.exists() {
        std::fs::remove_file(&db_path).map_err(|e| {
            error!("Failed to delete database file {:?}: {}", db_path, e);
            format!("Failed to delete database file: {}", e)
        })?;
        println!("✅ Database file deleted: {:?}", db_path);
    } else {
        warn!("Database file not found: {:?}", db_path);
    }

    let message = format!("Database '{}' deleted successfully", db_name);
    println!("{}", message);
    Ok(message)
}

#[tauri::command]
pub fn load_database(
    db_name: String,
    app_handle: AppHandle,
    databases: State<'_, DatabaseManager>,
) -> Result<DatabaseInfo, String> {
    println!("🔄 Loading database: {}", db_name);

    let app_data_dir = app_handle
        .path()
        .app_data_dir()
        .map_err(|e| format!("Failed to get app data directory: {}", e))?;

    let db_path = app_data_dir.join(format!("{}.sqlite", db_name));

    if !db_path.exists() {
        let error = format!("Database file not found: {}", db_name);
        error!("{}", error);
        return Err(error);
    }

    let db = SpatialDatabase::new(&db_path, db_name.clone(), Some(&app_handle)).map_err(|e| {
        error!("Failed to load database {}: {}", db_name, e);
        format!("Failed to load database: {}", e)
    })?;

    let info = db.get_database_info();

    let mut manager = databases.lock().unwrap();
    manager.insert(db_name.clone(), db);

    println!("✅ Database {} loaded successfully", db_name);
    Ok(info)
}

#[tauri::command]
pub fn import_data(
    request: ImportDataRequest,
    app_handle: AppHandle,
    databases: State<'_, DatabaseManager>,
) -> Result<String, String> {
    println!("📥 Importing data to database: {}", request.database_name);

    // Ensure database is loaded
    {
        let manager = databases.lock().unwrap();
        if !manager.contains_key(&request.database_name) {
            drop(manager);
            load_database(request.database_name.clone(), app_handle, databases.clone())?;
        }
    }

    let manager = databases.lock().unwrap();
    let db = manager
        .get(&request.database_name)
        .ok_or_else(|| format!("Database '{}' not found", request.database_name))?;

    let mut sites_imported = 0;
    let mut links_imported = 0;

    // Import sites
    for site in &request.sites {
        match db.insert_site(site) {
            Ok(_) => {
                sites_imported += 1;
                debug!("Inserted site: {}", site.site_id);
            }
            Err(e) => {
                error!("Failed to insert site {}: {}", site.site_id, e);
                return Err(format!("Failed to insert site {}: {}", site.site_id, e));
            }
        }
    }

    // Import links
    for link in &request.links {
        match db.insert_link(link) {
            Ok(_) => {
                links_imported += 1;
                debug!("Inserted link: {}", link.link_id);
            }
            Err(e) => {
                error!("Failed to insert link {}: {}", link.link_id, e);
                return Err(format!("Failed to insert link {}: {}", link.link_id, e));
            }
        }
    }

    // Handle KMZ import if provided
    let mut geometries_applied = 0;
    if let Some(kmz_data) = &request.kmz_base64 {
        println!("🗺️ Processing KMZ data...");

        match extract_geometries_from_zip(kmz_data) {
            Ok(geometries) => {
                println!("Extracted {} geometries from KMZ", geometries.len());

                // Apply geometries to existing records
                let mut sites = db.get_all_sites().map_err(|e| e.to_string())?;
                let mut links = db.get_all_links().map_err(|e| e.to_string())?;

                // geometries_applied += KmlProcessor::apply_geometries_to_sites(&mut sites, &geometries);
                // geometries_applied += KmlProcessor::apply_geometries_to_links(&mut links, &geometries);

                // Re-insert updated records
                for site in sites {
                    db.insert_site(&site).map_err(|e| e.to_string())?;
                }

                for link in links {
                    db.insert_link(&link).map_err(|e| e.to_string())?;
                }

                println!("Applied {} geometries from KML files", geometries_applied);
            }
            Err(e) => {
                error!("Failed to process KMZ data: {}", e);
                return Err(format!("Failed to process KMZ data: {}", e));
            }
        }
    }

    let message = if geometries_applied > 0 {
        format!(
            "Imported {} sites, {} links, and applied {} geometries",
            sites_imported, links_imported, geometries_applied
        )
    } else {
        format!(
            "Imported {} sites and {} links",
            sites_imported, links_imported
        )
    };

    println!("✅ {}", message);
    Ok(message)
}

#[tauri::command]
pub fn get_all_sites(
    db_name: String,
    app_handle: AppHandle,
    databases: State<'_, DatabaseManager>,
) -> Result<Vec<SiteRecord>, String> {
    debug!("📍 Getting all sites from database: {}", db_name);

    // Ensure database is loaded
    {
        let manager = databases.lock().unwrap();
        if !manager.contains_key(&db_name) {
            drop(manager);
            load_database(db_name.clone(), app_handle, databases.clone())?;
        }
    }

    let manager = databases.lock().unwrap();
    let db = manager
        .get(&db_name)
        .ok_or_else(|| format!("Database '{}' not found", db_name))?;

    let sites = db.get_all_sites().map_err(|e| {
        error!("Failed to get sites from {}: {}", db_name, e);
        format!("Failed to get sites: {}", e)
    })?;

    debug!("Retrieved {} sites from {}", sites.len(), db_name);
    Ok(sites)
}

#[tauri::command]
pub fn get_all_links(
    db_name: String,
    app_handle: AppHandle,
    databases: State<'_, DatabaseManager>,
) -> Result<Vec<LinkRecord>, String> {
    debug!("🔗 Getting all links from database: {}", db_name);

    // Ensure database is loaded
    {
        let manager = databases.lock().unwrap();
        if !manager.contains_key(&db_name) {
            drop(manager);
            load_database(db_name.clone(), app_handle, databases.clone())?;
        }
    }

    let manager = databases.lock().unwrap();
    let db = manager
        .get(&db_name)
        .ok_or_else(|| format!("Database '{}' not found", db_name))?;

    let links = db.get_all_links().map_err(|e| {
        error!("Failed to get links from {}: {}", db_name, e);
        format!("Failed to get links: {}", e)
    })?;

    debug!("Retrieved {} links from {}", links.len(), db_name);
    Ok(links)
}

#[tauri::command]
pub fn update_site(
    db_name: String,
    site: SiteRecord,
    app_handle: AppHandle,
    databases: State<'_, DatabaseManager>,
) -> Result<String, String> {
    println!("✏️ Updating site {} in database {}", site.site_id, db_name);

    // Ensure database is loaded
    {
        let manager = databases.lock().unwrap();
        if !manager.contains_key(&db_name) {
            drop(manager);
            load_database(db_name.clone(), app_handle, databases.clone())?;
        }
    }

    let manager = databases.lock().unwrap();
    let db = manager
        .get(&db_name)
        .ok_or_else(|| format!("Database '{}' not found", db_name))?;

    db.insert_site(&site).map_err(|e| {
        error!(
            "Failed to update site {} in {}: {}",
            site.site_id, db_name, e
        );
        format!("Failed to update site: {}", e)
    })?;

    let message = format!("Site {} updated successfully", site.site_id);
    println!("✅ {}", message);
    Ok(message)
}

#[tauri::command]
pub fn update_link(
    db_name: String,
    link: LinkRecord,
    app_handle: AppHandle,
    databases: State<'_, DatabaseManager>,
) -> Result<String, String> {
    println!("✏️ Updating link {} in database {}", link.link_id, db_name);

    // Ensure database is loaded
    {
        let manager = databases.lock().unwrap();
        if !manager.contains_key(&db_name) {
            drop(manager);
            load_database(db_name.clone(), app_handle, databases.clone())?;
        }
    }

    let manager = databases.lock().unwrap();
    let db = manager
        .get(&db_name)
        .ok_or_else(|| format!("Database '{}' not found", db_name))?;

    db.insert_link(&link).map_err(|e| {
        error!(
            "Failed to update link {} in {}: {}",
            link.link_id, db_name, e
        );
        format!("Failed to update link: {}", e)
    })?;

    let message = format!("Link {} updated successfully", link.link_id);
    println!("✅ {}", message);
    Ok(message)
}

#[tauri::command]
pub fn get_analytics(
    db_name: String,
    app_handle: AppHandle,
    databases: State<'_, DatabaseManager>,
) -> Result<AnalyticsResult, String> {
    println!("📊 Getting analytics from database: {}", db_name);

    // Ensure database is loaded
    {
        let manager = databases.lock().unwrap();
        if !manager.contains_key(&db_name) {
            drop(manager);
            load_database(db_name.clone(), app_handle, databases.clone())?;
        }
    }

    let manager = databases.lock().unwrap();
    let db = manager
        .get(&db_name)
        .ok_or_else(|| format!("Database '{}' not found", db_name))?;

    let analytics = db.get_analytics().map_err(|e| {
        error!("Failed to get analytics from {}: {}", db_name, e);
        format!("Failed to get analytics: {}", e)
    })?;

    println!("✅ Retrieved analytics from {}", db_name);
    Ok(analytics)
}

#[tauri::command]
pub fn find_shortest_path(
    db_name: String,
    source: String,
    destination: String,
    app_handle: AppHandle,
    databases: State<'_, DatabaseManager>,
) -> Result<PathResult, String> {
    println!(
        "🔍 Finding path from {} to {} in database {}",
        source, destination, db_name
    );

    // Ensure database is loaded
    {
        let manager = databases.lock().unwrap();
        if !manager.contains_key(&db_name) {
            drop(manager);
            load_database(db_name.clone(), app_handle, databases.clone())?;
        }
    }

    let manager = databases.lock().unwrap();
    let db = manager
        .get(&db_name)
        .ok_or_else(|| format!("Database '{}' not found", db_name))?;

    let path = db.find_shortest_path(&source, &destination).map_err(|e| {
        error!(
            "Failed to find path from {} to {} in {}: {}",
            source, destination, db_name, e
        );
        format!("Failed to find path: {}", e)
    })?;

    println!(
        "✅ Found path with {} hops from {} to {}",
        path.hop_count, source, destination
    );
    Ok(path)
}

// PBF Tile generation for MapLibre
#[tauri::command]
pub fn get_sites_pbf(
    db_name: String,
    z: u32,
    x: u32,
    y: u32,
    app_handle: AppHandle,
    databases: State<'_, DatabaseManager>,
) -> Result<Vec<u8>, String> {
    debug!(
        "🗺️ Generating sites PBF tile {}/{}/{} for database {}",
        z, x, y, db_name
    );

    // Ensure database is loaded
    {
        let manager = databases.lock().unwrap();
        if !manager.contains_key(&db_name) {
            drop(manager);
            load_database(db_name.clone(), app_handle, databases.clone())?;
        }
    }

    let manager = databases.lock().unwrap();
    let db = manager
        .get(&db_name)
        .ok_or_else(|| format!("Database '{}' not found", db_name))?;

    // Get sites with spatial filtering based on tile bounds
    let pbf_data = db.get_sites_pbf_tile(z, x, y).map_err(|e| {
        error!(
            "Failed to generate sites PBF tile {}/{}/{} for {}: {}",
            z, x, y, db_name, e
        );
        format!("Failed to generate PBF tile: {}", e)
    })?;

    debug!(
        "Generated sites PBF tile {}/{}/{} ({} bytes)",
        z,
        x,
        y,
        pbf_data.len()
    );
    Ok(pbf_data)
}

#[tauri::command]
pub fn get_links_pbf(
    db_name: String,
    z: u32,
    x: u32,
    y: u32,
    app_handle: AppHandle,
    databases: State<'_, DatabaseManager>,
) -> Result<Vec<u8>, String> {
    debug!(
        "🗺️ Generating links PBF tile {}/{}/{} for database {}",
        z, x, y, db_name
    );

    // Ensure database is loaded
    {
        let manager = databases.lock().unwrap();
        if !manager.contains_key(&db_name) {
            drop(manager);
            load_database(db_name.clone(), app_handle, databases.clone())?;
        }
    }

    let manager = databases.lock().unwrap();
    let db = manager
        .get(&db_name)
        .ok_or_else(|| format!("Database '{}' not found", db_name))?;

    // Get links with spatial filtering based on tile bounds
    let pbf_data = db.get_links_pbf_tile(z, x, y).map_err(|e| {
        error!(
            "Failed to generate links PBF tile {}/{}/{} for {}: {}",
            z, x, y, db_name, e
        );
        format!("Failed to generate PBF tile: {}", e)
    })?;

    debug!(
        "Generated links PBF tile {}/{}/{} ({} bytes)",
        z,
        x,
        y,
        pbf_data.len()
    );
    Ok(pbf_data)
}

#[tauri::command]
pub fn get_database_info(
    db_name: String,
    app_handle: AppHandle,
    databases: State<'_, DatabaseManager>,
) -> Result<DatabaseInfo, String> {
    debug!("ℹ️ Getting database info for: {}", db_name);

    // Ensure database is loaded
    {
        let manager = databases.lock().unwrap();
        if !manager.contains_key(&db_name) {
            drop(manager);
            load_database(db_name.clone(), app_handle, databases.clone())?;
        }
    }

    let manager = databases.lock().unwrap();
    let db = manager
        .get(&db_name)
        .ok_or_else(|| format!("Database '{}' not found", db_name))?;

    let info = db.get_database_info();
    debug!(
        "Database {} info: {} sites, {} links",
        db_name, info.site_count, info.link_count
    );
    Ok(info)
}

// src-tauri/src/commands.rs (add these new commands)

#[derive(Debug, Serialize, Deserialize)]
pub struct ImportRawDataRequest {
    pub database_name: String,
    pub sites_csv_base64: Option<String>,
    pub links_csv_base64: Option<String>,
    pub kml_zip_base64: Option<String>,
}
use std::path::Path;

#[derive(Debug, Serialize, Deserialize)]
pub struct ImportFromFilesRequest {
    pub database_name: String,
    pub sites_csv_path: Option<String>,
    pub links_csv_path: Option<String>,
    pub kml_zip_path: Option<String>,
}
// #[tauri::command]
// pub fn import_from_files(
//     request: ImportFromFilesRequest,
//     app_handle: AppHandle,
//     databases: State<'_, DatabaseManager>,
// ) -> Result<String, String> {
//     println!("📦 Processing file import for database: {}", request.database_name);

//     // Ensure database is loaded
//     {
//         let manager = databases.lock().unwrap();
//         if !manager.contains_key(&request.database_name) {
//             drop(manager);
//             load_database(request.database_name.clone(), app_handle.clone(), databases.clone())?;
//         }
//     }

//     let manager = databases.lock().unwrap();
//     let db = manager.get(&request.database_name)
//         .ok_or_else(|| format!("Database '{}' not found", request.database_name))?;

//     let mut sites_imported = 0;
//     let mut links_imported = 0;
//     let mut geometries_imported = 0;

//     // --- Sites CSV ---
//     if let Some(ref sites_csv_path) = request.sites_csv_path {
//         println!("🏢 Processing sites CSV file: {}", sites_csv_path);
//         if !Path::new(sites_csv_path).exists() {
//             return Err(format!("Sites CSV file not found: {}", sites_csv_path));
//         }
//         let sites = parse_sites_csv_from_file(sites_csv_path)
//             .map_err(|e| format!("Failed to parse sites CSV: {}", e))?;
//         println!("Parsed {} site records", sites.len());

//         for site in &sites {
//             match db.insert_site(site) {
//                 Ok(_) => {
//                     sites_imported += 1;
//                     if sites_imported % 1000 == 0 {
//                         println!("Imported {} sites so far...", sites_imported);
//                     }
//                 }
//                 Err(e) => error!("Failed to insert site {}: {}", site.site_id, e),
//             }
//         }
//         println!("✅ Imported {} sites", sites_imported);
//     }

//     // --- Links CSV ---
//     if let Some(ref links_csv_path) = request.links_csv_path {
//         println!("🔗 Processing links CSV file: {}", links_csv_path);
//         if !Path::new(links_csv_path).exists() {
//             return Err(format!("Links CSV file not found: {}", links_csv_path));
//         }
//         let links = parse_links_csv_from_file(links_csv_path)
//             .map_err(|e| format!("Failed to parse links CSV: {}", e))?;
//         println!("Parsed {} link records", links.len());

//         for link in &links {
//             match db.insert_link(link) {
//                 Ok(_) => {
//                     links_imported += 1;
//                     if links_imported % 1000 == 0 {
//                         println!("Imported {} links so far...", links_imported);
//                     }
//                 }
//                 Err(e) => error!("Failed to insert link {}: {}", link.link_id, e),
//             }
//         }
//         println!("✅ Imported {} links", links_imported);
//     }

//     // --- KML ZIP ---
//     if let Some(ref kml_zip_path) = request.kml_zip_path {
//         println!("🗺️ Processing KML ZIP file: {}", kml_zip_path);
//         if !Path::new(kml_zip_path).exists() {
//             return Err(format!("KML ZIP file not found: {}", kml_zip_path));
//         }

//         let zip_data = fs::read(kml_zip_path)
//             .map_err(|e| format!("Failed to read KML ZIP file: {}", e))?;
//         let base64_data = base64::encode(&zip_data);

//         match extract_geometries_from_zip(&base64_data) {
//             Ok(geometries) => {
//                 println!("📍 Extracted {} geometries from KML ZIP", geometries.len());

//                 let kml_records: Vec<KmlRecord> = geometries
//                     .into_iter()
//                     .map(|g| KmlRecord {
//                         lib_no: g.lib_no,
//                         geometry_type: g.geometry_type,
//                         wkt: g.wkt,
//                     })
//                     .collect();

//                 // Drop read lock and get mutable DB reference
//                 drop(manager);
//                 let mut manager = databases.lock().unwrap();
//                 let db_mut = manager.get_mut(&request.database_name)
//                     .ok_or_else(|| format!("Database '{}' not found", request.database_name))?;

//                 db_mut.insert_kml_bulk(&kml_records)
//                     .map_err(|e| format!("Failed to insert KML records: {}", e))?;

//                 geometries_imported = kml_records.len();
//                 println!("✅ Inserted {} KML records into database", geometries_imported);
//             }
//             Err(e) => warn!("Failed to process KML ZIP: {}", e),
//         }
//     }

//     let message = format!(
//         "Imported {} sites, {} links, inserted {} KML geometries",
//         sites_imported, links_imported, geometries_imported
//     );
//     println!("✅ {}", message);
//     Ok(message)
// }

use std::sync::Mutex;
use tauri::Emitter;
use tokio::task;

#[derive(Serialize, Clone)]
struct ProgressPayload {
    stage: String,
    processed: usize,
    total: usize,
}

#[tauri::command]
pub async fn import_from_files(
    request: ImportFromFilesRequest,
    app_handle: AppHandle,
    databases: State<'_, Arc<Mutex<HashMap<String, SpatialDatabase>>>>,
) -> Result<String, String> {
    // Ensure database is loaded before spawning
    {
        let manager = databases.lock().unwrap();
        if !manager.contains_key(&request.database_name) {
            drop(manager);
            load_database(
                request.database_name.clone(),
                app_handle.clone(),
                databases, // pass State directly here
            )?;
        }
    }

    let handle_clone = app_handle.clone();
    // let db_state = databases.inner().clone(); // ✅ Arc<Mutex<...>>
    let db_state: Arc<Mutex<HashMap<String, SpatialDatabase>>> =
    Arc::clone(databases.inner());


    if !db_state
        .lock()
        .unwrap()
        .contains_key(&request.database_name)
    {
        load_database(
            request.database_name.clone(),
            app_handle.clone(),
            databases, // move State here
        )?;
    }

    tokio::task::spawn_blocking(move || import_from_files_inner(request, handle_clone, db_state))
        .await
        .map_err(|e| format!("Task join error: {}", e))?
}

fn import_from_files_inner(
    request: ImportFromFilesRequest,
    app_handle: AppHandle,
    databases: Arc<Mutex<HashMap<String, SpatialDatabase>>>,
) -> Result<String, String> {
    let manager = databases.lock().unwrap();
    let db = manager
        .get(&request.database_name)
        .ok_or_else(|| format!("Database '{}' not found", request.database_name))?;

    let mut sites_imported = 0;
    let mut links_imported = 0;
    let mut geometries_imported = 0;

    // --- Sites CSV ---
    if let Some(ref sites_csv_path) = request.sites_csv_path {
        if !Path::new(sites_csv_path).exists() {
            return Err(format!("Sites CSV file not found: {}", sites_csv_path));
        }
        let sites = parse_sites_csv_from_file(sites_csv_path)
            .map_err(|e| format!("Failed to parse sites CSV: {}", e))?;

        let total = sites.len();
        for (i, site) in sites.iter().enumerate() {
            if db.insert_site(site).is_ok() {
                sites_imported += 1;
            }
            if (i + 1) % 500 == 0 || i + 1 == total {
                let _ = app_handle.emit(
                    "import-progress",
                    ProgressPayload {
                        stage: "sites".into(),
                        processed: i + 1,
                        total,
                    },
                );
            }
        }
    }

    // --- Links CSV ---
    if let Some(ref links_csv_path) = request.links_csv_path {
        if !Path::new(links_csv_path).exists() {
            return Err(format!("Links CSV file not found: {}", links_csv_path));
        }
        let links = parse_links_csv_from_file(links_csv_path)
            .map_err(|e| format!("Failed to parse links CSV: {}", e))?;

        let total = links.len();
        for (i, link) in links.iter().enumerate() {
            if db.insert_link(link).is_ok() {
                links_imported += 1;
            }
            if (i + 1) % 500 == 0 || i + 1 == total {
                let _ = app_handle.emit(
                    "import-progress",
                    ProgressPayload {
                        stage: "links".into(),
                        processed: i + 1,
                        total,
                    },
                );
            }
        }
    }

    // --- KML ZIP ---
    if let Some(ref kml_zip_path) = request.kml_zip_path {
        if !Path::new(kml_zip_path).exists() {
            return Err(format!("KML ZIP file not found: {}", kml_zip_path));
        }

        let zip_data =
            fs::read(kml_zip_path).map_err(|e| format!("Failed to read KML ZIP file: {}", e))?;
        let base64_data = base64::encode(&zip_data);

        match extract_geometries_from_zip(&base64_data) {
            Ok(geometries) => {
                let kml_records: Vec<KmlRecord> = geometries
                    .into_iter()
                    .map(|g| KmlRecord {
                        lib_no: g.lib_no,
                        geometry_type: g.geometry_type,
                        wkt: g.wkt,
                    })
                    .collect();

                drop(manager);
                let mut manager = databases.lock().unwrap();
                let db_mut = manager
                    .get_mut(&request.database_name)
                    .ok_or_else(|| format!("Database '{}' not found", request.database_name))?;

                let total = kml_records.len();
                for (i, chunk) in kml_records.chunks(500).enumerate() {
                    db_mut
                        .insert_kml_bulk(chunk)
                        .map_err(|e| format!("Failed to insert KML records: {}", e))?;
                    geometries_imported += chunk.len();

                    let _ = app_handle.emit(
                        "import-progress",
                        ProgressPayload {
                            stage: "kml".into(),
                            processed: ((i + 1) * 500).min(total),
                            total,
                        },
                    );
                }
            }
            Err(e) => warn!("Failed to process KML ZIP: {}", e),
        }
    }

    Ok(format!(
        "Imported {} sites, {} links, inserted {} KML geometries",
        sites_imported, links_imported, geometries_imported
    ))
}

use csv::ReaderBuilder;
use std::error::Error;
use std::fs::File;

pub fn parse_sites_csv_from_file(file_path: &str) -> Result<Vec<SiteRecord>, Box<dyn Error>> {
    println!("📊 Parsing sites CSV from file: {}", file_path);

    let file = File::open(file_path)?;
    println!("📁 File opened successfully");

    let mut reader = ReaderBuilder::new().has_headers(true).from_reader(file);
    let headers = reader.headers()?;
    println!("Headers: {:?}", headers);

    let mut sites = Vec::new();

    for (i, result) in reader.deserialize::<SiteRecord>().enumerate() {
        match result {
            Ok(site) => {
                sites.push(site);
            }
            Err(e) => {
                warn!("⚠️ Line {}: Failed to parse site record: {}", i + 1, e);
            }
        }
    }

    println!("✅ Parsed {} valid site records", sites.len());
    Ok(sites)
}

fn parse_links_csv_from_file(
    file_path: &str,
) -> Result<Vec<LinkRecord>, Box<dyn std::error::Error>> {
    println!("📊 Parsing links CSV from file: {}", file_path);

    use csv::ReaderBuilder;
    use std::fs::File;

    let file = File::open(file_path)?;
    let mut reader = ReaderBuilder::new().has_headers(true).from_reader(file);

    let mut links = Vec::new();

    for result in reader.deserialize() {
        match result {
            Ok(link) => {
                let link: LinkRecord = link;
                links.push(link);
            }
            Err(e) => {
                warn!("Failed to parse link record: {}", e);
            }
        }
    }

    println!("✅ Parsed {} link records from file", links.len());
    Ok(links)
}
