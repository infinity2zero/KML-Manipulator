import { bootstrapApplication } from "@angular/platform-browser";
import { AppComponent } from "./app/app.component";
import { appConfig } from "./app/app.config";
import { getCurrentWindow } from '@tauri-apps/api/window';

bootstrapApplication(AppComponent, appConfig)
.then(async () => {
    // const win = getCurrentWindow();
    // // Show and maximize only once Angular is fully up
    // await win.show();
    // await win.maximize();
  })
.catch((err) =>
  console.error(err),
);
