// import {
//   AfterViewInit,
//   ChangeDetectorRef,
//   Component,
//   ElementRef,
//   NgZone,
//   OnDestroy,
//   Renderer2,
//   ViewChild
// } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { NzLayoutModule } from 'ng-zorro-antd/layout';
// import { NzButtonModule } from 'ng-zorro-antd/button';
// import { NzIconModule, NzIconService } from 'ng-zorro-antd/icon';
// import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';

// import { getCurrentWindow } from '@tauri-apps/api/window';
// import { UnlistenFn } from '@tauri-apps/api/event';
// import { platform, arch } from '@tauri-apps/plugin-os';
// import { register, isRegistered, unregister } from '@tauri-apps/plugin-global-shortcut';
// // Optional: when we add per-OS polish later, we’ll swap this to a real platform call.
// // For now, we keep class hooks, and you can add platform classes manually if you want.

// @Component({
//   selector: 'app-vscode-layout',
//   standalone: true,
//   imports: [CommonModule, NzLayoutModule, NzButtonModule, NzIconModule, RouterOutlet,RouterLink, RouterLinkActive ],
//   templateUrl: './layout.html',
//   styleUrls: ['./layout.scss']
// })
// export class MainLayoutComponent implements AfterViewInit, OnDestroy {
//   @ViewChild('appContainer', { static: true }) container!: ElementRef<HTMLDivElement>;

//   theme: 'dark-theme' | 'light-theme' = 'dark-theme';
//   bootSplashHidden = false;

//   private window = getCurrentWindow();
//   private unlistenResize?: UnlistenFn;
//   private destroyed = false;
//   private removedBootSplash = false;
//   private resizeDebounce?: any;
//   private shortcuts: string[] = [];
//   constructor(
//     private iconService: NzIconService,
//     private renderer: Renderer2,
//     private cdr: ChangeDetectorRef,
//     private zone: NgZone
//   ) {
//     this.iconService.fetchFromIconfont({ scriptUrl: '//at.alicdn.com/t/c/font_XXXXXX.js' });
//   }

//   async ngAfterViewInit() {
//     // Optional: add platform class later when OS API is wired
//     const plt: any = await platform();  // 'linux' | 'darwin' | 'windows'
//     const cpu = await arch();      // e.g., 'x86_64', 'aarch64'
//     document.documentElement.classList.add(`platform-${plt}`, `arch-${cpu}`);
//     await this.registerShortcuts(plt);

//     // Smooth resize masking and splash removal
//     if (!this.container?.nativeElement) return;

//     // onResized often returns a Promise of an unlisten function
//     this.unlistenResize = await this.window.onResized(() => {
//       // Guard against lifecycle races or *ngIf toggles
//       const el = this.container?.nativeElement;
//       if (!el || this.destroyed) return;

//       // Keep DOM work outside Angular
//       this.zone.runOutsideAngular(() => {
//         this.renderer.addClass(el, 'pre-resize');
//         clearTimeout(this.resizeDebounce);
//         this.resizeDebounce = setTimeout(() => {
//           // Re-check because element may have been removed meanwhile
//           const el2 = this.container?.nativeElement;
//           if (!el2 || this.destroyed) return;
//           this.renderer.removeClass(el2, 'pre-resize');
//         }, 60);
//       });

//       // If removeBootSplashOnce mutates Angular state, run it inside Angular
//       this.removeBootSplashOnce();
//     });

//     // Failsafe splash removal
//     setTimeout(() => this.removeBootSplashOnce(), 1500);


//   }

//   private async registerShortcuts(plt: 'linux' | 'darwin' | 'windows') {
//     const mod = plt === 'darwin' ? 'Command' : 'Control';
//     const defs = [
//       { combo: `${mod}+M`, action: () => this.minimize() },
//       { combo: `${mod}+W`, action: () => this.close() }
//     ];
//     for (const { combo, action } of defs) {
//       if (!(await isRegistered(combo))) {
//         await register(combo, action);
//         this.shortcuts.push(combo);
//       }
//     }
//   }

//   private async unregisterShortcuts() {
//     for (const combo of this.shortcuts) {
//       try { await unregister(combo); } catch { }
//     }
//     this.shortcuts = [];
//   }

//   ngOnDestroy() {
//     this.destroyed = true;
//     clearTimeout(this.resizeDebounce);
//     try { this.unlistenResize?.(); } catch { }
//     this.unregisterShortcuts();
//   }

//   toggleTheme(): void {
//     const root = document.documentElement;
//     root.classList.add('theme-transition', 'theme-flip');
//     this.theme = this.theme === 'dark-theme' ? 'light-theme' : 'dark-theme';
//     setTimeout(() => {
//       root.classList.remove('theme-transition', 'theme-flip');
//     }, 240);
//   }

//   async minimize() { await this.window.minimize(); }
//   async toggleMaximize() { await this.window.toggleMaximize(); }
//   async close() { await this.window.close(); }

//   removeBootSplashOnce() {
//     if (this.removedBootSplash) return;
//     this.removedBootSplash = true;
//     this.bootSplashHidden = true;
//     this.cdr.markForCheck();
//   }
// }

// src/app/layout/main-layout.component.ts
import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  ElementRef,
  NgZone,
  OnDestroy,
  OnInit,
  Renderer2,
  ViewChild
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { NzLayoutModule } from 'ng-zorro-antd/layout';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzIconModule, NzIconService } from 'ng-zorro-antd/icon';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { getCurrentWindow } from '@tauri-apps/api/window';
import { UnlistenFn } from '@tauri-apps/api/event';
import { platform, arch } from '@tauri-apps/plugin-os';
import { register, isRegistered, unregister } from '@tauri-apps/plugin-global-shortcut';

// Import our theme service
import { ThemeService } from '../../shared/services/theme.service';
import { DatabaseService } from '../../shared/services/database.service';

@Component({
  selector: 'app-main-layout',
  standalone: true,
  imports: [
    CommonModule, 
    NzLayoutModule, 
    NzButtonModule, 
    NzIconModule, 
    RouterOutlet, 
    RouterLink, 
    RouterLinkActive
  ],
  templateUrl: './layout.html',
  styleUrls: ['./layout.scss']
})
export class MainLayoutComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild('appContainer', { static: true }) container!: ElementRef<HTMLDivElement>;

  private destroy$ = new Subject<void>();
  
  // Theme properties - now managed by ThemeService
  isDarkTheme = false;
  theme: 'dark-theme' | 'light-theme' = 'dark-theme';
  
  // App state
  bootSplashHidden = false;
  currentDatabase: string | null = null;
  
  // Tauri window management
  private window = getCurrentWindow();
  private unlistenResize?: UnlistenFn;
  private destroyed = false;
  private removedBootSplash = false;
  private resizeDebounce?: any;
  private shortcuts: string[] = [];

  // Navigation items with proper routing
  navigationItems = [
    { 
      icon: 'dashboard', 
      title: 'Dashboard', 
      route: 'test', 
      active: false 
    },
    { 
      icon: 'database', 
      title: 'Databases', 
      route: 'databases', 
      active: false 
    },
    { 
      icon: 'environment', 
      title: 'Network Sites', 
      route: '/sites', 
      active: false 
    },
    { 
      icon: 'link', 
      title: 'Network Links', 
      route: '/links', 
      active: false 
    },
    { 
      icon: 'node-expand', 
      title: 'Path Finder', 
      route: '/pathfinder', 
      active: false 
    },
    { 
      icon: 'global', 
      title: 'Network Map', 
      route: '/map', 
      active: false 
    }
  ];

  bottomNavigationItems = [
    { 
      icon: 'bar-chart', 
      title: 'Analytics', 
      route: '/analytics', 
      active: false 
    },
    { 
      icon: 'setting', 
      title: 'Settings', 
      route: '/settings', 
      active: false 
    },
    { 
      icon: 'tool', 
      title: 'Tools', 
      route: '/tools', 
      active: false 
    }
  ];

  constructor(
    private iconService: NzIconService,
    private renderer: Renderer2,
    private cdr: ChangeDetectorRef,
    private zone: NgZone,
    private themeService: ThemeService,
    private databaseService: DatabaseService
  ) {
    // Load custom icons if needed
    this.iconService.fetchFromIconfont({ 
      scriptUrl: '//at.alicdn.com/t/c/font_XXXXXX.js' 
    });
  }

  ngOnInit() {
    // Subscribe to theme changes
    this.themeService.isDarkTheme$
      .pipe(takeUntil(this.destroy$))
      .subscribe(isDark => {
        const oldTheme = this.theme;
        this.isDarkTheme = isDark;
        this.theme = isDark ? 'dark-theme' : 'light-theme';
        
        // Apply theme change animation if theme actually changed
        if (oldTheme !== this.theme) {
          this.applyThemeTransition();
        }
        
        this.cdr.markForCheck();
      });

    // Subscribe to current database changes
    this.databaseService.currentDatabase$
      .pipe(takeUntil(this.destroy$))
      .subscribe(db => {
        this.currentDatabase = db;
        this.cdr.markForCheck();
      });
  }

  async ngAfterViewInit() {
    // Add platform-specific classes
    const plt: any = await platform();
    const cpu = await arch();
    document.documentElement.classList.add(`platform-${plt}`, `arch-${cpu}`);
    await this.registerShortcuts(plt);

    // Setup window resize handling
    if (!this.container?.nativeElement) return;

    this.unlistenResize = await this.window.onResized(() => {
      const el = this.container?.nativeElement;
      if (!el || this.destroyed) return;

      this.zone.runOutsideAngular(() => {
        this.renderer.addClass(el, 'pre-resize');
        clearTimeout(this.resizeDebounce);
        this.resizeDebounce = setTimeout(() => {
          const el2 = this.container?.nativeElement;
          if (!el2 || this.destroyed) return;
          this.renderer.removeClass(el2, 'pre-resize');
        }, 60);
      });

      this.removeBootSplashOnce();
    });

    // Failsafe splash removal
    setTimeout(() => this.removeBootSplashOnce(), 1500);
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
    this.destroyed = true;
    clearTimeout(this.resizeDebounce);
    try { 
      this.unlistenResize?.(); 
    } catch { }
    this.unregisterShortcuts();
  }

  private async registerShortcuts(plt: 'linux' | 'darwin' | 'windows') {
    const mod = plt === 'darwin' ? 'Command' : 'Control';
    const defs = [
      { combo: `${mod}+M`, action: () => this.minimize() },
      { combo: `${mod}+W`, action: () => this.close() },
      { combo: `${mod}+Shift+D`, action: () => this.toggleTheme() }
    ];
    
    for (const { combo, action } of defs) {
      if (!(await isRegistered(combo))) {
        await register(combo, action);
        this.shortcuts.push(combo);
      }
    }
  }

  private async unregisterShortcuts() {
    for (const combo of this.shortcuts) {
      try { 
        await unregister(combo); 
      } catch { }
    }
    this.shortcuts = [];
  }

  private applyThemeTransition(): void {
    const root = document.documentElement;
    root.classList.add('theme-transition', 'theme-flip');
    
    setTimeout(() => {
      root.classList.remove('theme-transition', 'theme-flip');
    }, 240);
  }

  // Theme toggle - now uses ThemeService
  toggleTheme(): void {
    this.themeService.toggleTheme();
  }

  // Window controls
  async minimize() { 
    await this.window.minimize(); 
  }

  async toggleMaximize() { 
    await this.window.toggleMaximize(); 
  }

  async close() { 
    await this.window.close(); 
  }

  // Boot splash management
  removeBootSplashOnce() {
    if (this.removedBootSplash) return;
    this.removedBootSplash = true;
    this.bootSplashHidden = true;
    this.cdr.markForCheck();
  }

  // Navigation helpers
  isRouteActive(route: string): boolean {
    // You can implement more sophisticated route checking here
    return window.location.pathname === route;
  }

  navigateToRoute(route: string) {
    // Handle navigation - you might want to use Angular router here
    console.log(`Navigating to: ${route}`);
  }

  // Database helpers
  getDatabaseDisplayName(): string {
    return this.currentDatabase || 'No Database Selected';
  }

  getDatabaseStatus(): 'connected' | 'disconnected' {
    return this.currentDatabase ? 'connected' : 'disconnected';
  }
}
