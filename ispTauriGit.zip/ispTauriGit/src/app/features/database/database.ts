import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NzCardModule } from 'ng-zorro-antd/card';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzModalModule } from 'ng-zorro-antd/modal';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzTableModule } from 'ng-zorro-antd/table';
import { NzTagModule } from 'ng-zorro-antd/tag';
import { NzDividerModule } from 'ng-zorro-antd/divider';
import { NzStatisticModule } from 'ng-zorro-antd/statistic';
import { NzGridModule } from 'ng-zorro-antd/grid';
import { NzDropDownModule } from 'ng-zorro-antd/dropdown';
import { NzListModule } from 'ng-zorro-antd/list';
import { NzSpinModule } from 'ng-zorro-antd/spin';
import { NzStepsModule } from 'ng-zorro-antd/steps';
import { DatabaseService } from '../../shared/services/database.service';
import { NzMessageService } from 'ng-zorro-antd/message';
// import { open } from '@tauri-apps/api/dialog';
import { open, save, message, confirm, ask } from '@tauri-apps/plugin-dialog';
import { listen } from '@tauri-apps/api/event';
import { NzProgressComponent } from "ng-zorro-antd/progress";

interface DatabaseInfo {
  name: string;
  site_count: number;
  link_count: number;
  created_at: string;
  size_bytes: number;
}

interface SelectedFiles {
  sites_csv?: string;
  links_csv?: string;
  kml_zip?: string;
}

@Component({
  selector: 'app-databases',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    NzCardModule,
    NzButtonModule,
    NzIconModule,
    NzModalModule,
    NzFormModule,
    NzInputModule,
    NzTableModule,
    NzTagModule,
    NzDividerModule,
    NzStatisticModule,
    NzGridModule,
    NzDropDownModule,
    NzListModule,
    NzSpinModule,
    NzStepsModule,
    NzProgressComponent
  ],
  templateUrl: './database.html',
  styleUrls: ['./database.scss']
})
export class DatabasesComponent implements OnInit {
  databases: DatabaseInfo[] = [];
  // databases: any = [];
  currentDatabase: string | null = null;
  showCreateModal = false;
  showImportModal = false;
  creating = false;
  importing = false;
  createForm: FormGroup;
  selectedFiles: SelectedFiles = {};
  selectedDatabaseForImport = '';

  // Stepper for create process
  currentStep = 0;

  importProgress: {
    stage: string;
    processed: number;
    total: number;
    percentage: number;
    message?: string;
  } | null = null;

  constructor(
    private fb: FormBuilder,
    private databaseService: DatabaseService,
    private message: NzMessageService
  ) {
    this.createForm = this.fb.group({
      name: ['', [Validators.required, Validators.pattern(/^[a-zA-Z0-9_-]+$/)]],
      description: ['']
    });
  }

  ngOnInit() {
    this.loadDatabases();
    this.databaseService.currentDatabase$.subscribe(db => {
      this.currentDatabase = db;
    });
  }

  async loadDatabases() {
    try {
      const db:any = await this.databaseService.listDatabases();
      // console.log('Databases:', db);
      this.databases = []; 
      for (const d of db) {
        try {
          const info = await this.databaseService.getDatabaseInfo(d.name);
          console.log('DatabasesInfo:', info);
          this.databases.push(info);
        } catch (error) {
          this.databases.push({
            name:d.name,
            site_count: 0,
            link_count: 0,
            created_at: new Date().toISOString(),
            size_bytes: 0
          });
        }
      }
    } catch (error) {
      this.message.error('Failed to load databases');
    }
  }

  async createDatabase() {
    if (this.createForm.invalid) return;

    this.creating = true;
    try {
      const { name, description } = this.createForm.value;

      // Step 1: Create database with schema only
      this.message.info('Creating database schema...');
      await this.databaseService.createDatabase(name, description);

      this.message.success('Database created successfully');
      this.currentStep = 1;

      await this.loadDatabases();
    } catch (error: any) {
      console.error(error);
      this.message.error(`Failed to create database: ${error.message || error}`);
    } finally {
      this.creating = false;
    }
  }

  // Native file selection using Tauri dialog
  async selectSitesFile() {
    try {
      const selected = await open({
        filters: [
          {
            name: 'CSV',
            extensions: ['csv']
          }
        ]
      });

      if (selected && typeof selected === 'string') {
        this.selectedFiles.sites_csv = selected;
        this.message.success(`Selected sites file: ${selected.split('/').pop()}`);
      }
    } catch (error) {
      this.message.error('Failed to select sites file');
    }
  }

  async selectLinksFile() {
    try {
      const selected = await open({
        filters: [
          {
            name: 'CSV',
            extensions: ['csv']
          }
        ]
      });

      if (selected && typeof selected === 'string') {
        this.selectedFiles.links_csv = selected;
        this.message.success(`Selected links file: ${selected.split('/').pop()}`);
      }
    } catch (error) {
      this.message.error('Failed to select links file');
    }
  }

  async selectKmlFile() {
    try {
      const selected = await open({
        filters: [
          {
            name: 'ZIP/KMZ',
            extensions: ['zip', 'kmz']
          }
        ]
      });

      if (selected && typeof selected === 'string') {
        this.selectedFiles.kml_zip = selected;
        this.message.success(`Selected KML file: ${selected.split('/').pop()}`);
      }
    } catch (error) {
      this.message.error('Failed to select KML file');
    }
  }

  async importData() {
    if (!this.hasSelectedFiles()) return;

    this.importing = true;
    let progressUnlisten: (() => void) | null = null;

    try {
      const dbName = this.currentStep > 0 ? this.createForm.value.name : this.selectedDatabaseForImport;

      // Initialize progress tracking
      this.importProgress = {
        stage: 'initializing',
        processed: 0,
        total: 0,
        percentage: 0,
        message: 'Starting import...'
      };

      // Listen for progress updates from Rust
      progressUnlisten = await listen('import-progress', (event: any) => {
        const progress = event.payload as {
          stage: string;
          processed: number;
          total: number;
          message?: string;
        };

        // Update progress state
        this.importProgress = {
          ...progress,
          percentage: progress.total > 0 ? Math.round((progress.processed / progress.total) * 100) : 0
        };

        // Show stage-specific messages
        const stageMessages = {
          sites: '📍 Importing sites...',
          links: '🔗 Importing links...',
          kml: '🗺️ Processing KML geometries...'
        };

        const displayMessage = progress.message ||
          stageMessages[progress.stage as keyof typeof stageMessages] ||
          `Processing ${progress.stage}...`;

        // Update UI message
        this.message.loading(
          `${displayMessage} (${progress.processed}/${progress.total})`,
          { nzDuration: 0 } // Keep message until manually cleared
        );

        // Log progress for debugging
        console.log(`Import Progress - ${progress.stage}: ${progress.processed}/${progress.total}`, progress);
      });

      this.message.loading('Processing and importing data...', { nzDuration: 0 });

      // Send file paths directly to Rust for parallel processing
      const result = await this.databaseService.importFromFiles(dbName, this.selectedFiles);

      // Clear loading message and show success
      this.message.remove();
      this.message.success(`Import completed: ${result}`, { nzDuration: 5000 });

      // Reset progress
      this.importProgress = null;

      if (this.currentStep > 0) {
        // Complete the creation flow
        this.resetCreateForm();
      } else {
        // Complete import to existing database
        this.showImportModal = false;
        this.selectedFiles = {};
      }

      await this.loadDatabases();

    } catch (error: any) {
      console.error('Import error:', error);
      this.message.remove();
      this.message.error(`Import failed: ${error.message || error}`, { nzDuration: 10000 });

      // Reset progress on error
      this.importProgress = null;

    } finally {
      this.importing = false;

      // Clean up progress listener
      if (progressUnlisten) {
        progressUnlisten();
      }
    }
  }

  selectDatabase(dbName: string) {
    const database = this.databases.find((db:any) => db.name === dbName);

    // Don't allow switching to empty databases
    if (database && (database.site_count > 0 || database.link_count > 0)) {
      this.databaseService.setCurrentDatabase(dbName);
      this.message.success(`Selected database: ${dbName}`);
    } else {
      this.message.warning('Cannot select empty database. Please import data first.');
    }
  }

  async deleteDatabase(dbName: string) {
    try {
      // The result will be the success message from Rust
      const result = await this.databaseService.deleteDatabase(dbName);

      // Show the actual message returned from the backend
      this.message.success(result); // This will show: "Database 'dbName' deleted successfully"

      // Update UI state
      if (this.currentDatabase === dbName) {
        this.databaseService.setCurrentDatabase('');
      }

      // Reload the database list
      await this.loadDatabases();

    } catch (error: any) {
      // The error will be the specific error message from Rust
      console.error('Delete database error:', error);

      // Show the actual error message from the backend
      this.message.error(`Failed to delete database: ${error}`);

      // error could be messages like:
      // - "Failed to acquire database lock"
      // - "Failed to get app data directory: <specific error>"
      // - "Failed to delete database file: <specific error>"
    }
  }

  showImportDataModal(dbName?: string) {
    this.selectedDatabaseForImport = dbName || '';
    this.showImportModal = true;
    this.selectedFiles = {};
  }

  exportDatabase(dbName: string) {
    this.message.info('Export functionality coming soon');
  }

  refreshDatabases() {
    this.loadDatabases();
  }

  public resetCreateForm() {
    this.showCreateModal = false;
    this.createForm.reset();
    this.selectedFiles = {};
    this.currentStep = 0;
  }

  formatDate(dateStr: string): string {
    return new Date(dateStr).toLocaleDateString();
  }

  formatFileSize(bytes: number): string {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  }

  getSelectedFilesSummary(): string[] {
    const summary = [];
    if (this.selectedFiles.sites_csv) {
      summary.push(`Sites: ${this.selectedFiles.sites_csv.split('/').pop()}`);
    }
    if (this.selectedFiles.links_csv) {
      summary.push(`Links: ${this.selectedFiles.links_csv.split('/').pop()}`);
    }
    if (this.selectedFiles.kml_zip) {
      summary.push(`KML: ${this.selectedFiles.kml_zip.split('/').pop()}`);
    }
    return summary;
  }

  isDatabaseEmpty(db: DatabaseInfo): boolean {
    return db.site_count === 0 && db.link_count === 0;
  }



  hasSelectedFiles(): boolean {
    return Object.values(this.selectedFiles).some(file => file !== null && file !== undefined);
  }

  // Helper method to get current progress percentage for UI
  getProgressPercentage(): number {
    return this.importProgress?.percentage || 0;
  }

  // Helper method to get current stage display name
  getCurrentStageDisplay(): string {
    if (!this.importProgress) return '';

    const stageDisplayNames = {
      sites: 'Sites',
      links: 'Links',
      kml: 'KML Geometries',
      initializing: 'Initializing'
    };

    return stageDisplayNames[this.importProgress.stage as keyof typeof stageDisplayNames] || this.importProgress.stage;
  }

  isStageCompleted(stage: string): boolean {
    if (!this.importProgress) return false;

    const stageOrder = ['sites', 'links', 'kml'];
    const currentStageIndex = stageOrder.indexOf(this.importProgress.stage);
    const checkStageIndex = stageOrder.indexOf(stage);

    // Stage is completed if:
    // 1. We're past this stage, OR
    // 2. We're on this stage and it's 100% complete
    return currentStageIndex > checkStageIndex ||
      (currentStageIndex === checkStageIndex && this.importProgress.percentage === 100);
  }
}

