// src/app/pages/pathfinder/pathfinder.component.ts
import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NzCardModule } from 'ng-zorro-antd/card';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzTableModule } from 'ng-zorro-antd/table';
import { NzTagModule } from 'ng-zorro-antd/tag';
import { NzDividerModule } from 'ng-zorro-antd/divider';
import { NzResultModule } from 'ng-zorro-antd/result';
import { NzStatisticModule } from 'ng-zorro-antd/statistic';
import { NzGridModule } from 'ng-zorro-antd/grid';
import { NzStepsModule } from 'ng-zorro-antd/steps';
import { NzTimelineModule } from 'ng-zorro-antd/timeline';
import { DatabaseService } from '../../shared/services/database.service';
import { SiteRecord, PathResult } from '../../shared/interfaces/database.interface';
import { Subject } from 'rxjs';
import { takeUntil, debounceTime, distinctUntilChanged } from 'rxjs/operators';

@Component({
  selector: 'app-pathfinder',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    NzCardModule,
    NzFormModule,
    NzInputModule,
    NzSelectModule,
    NzButtonModule,
    NzIconModule,
    NzTableModule,
    NzTagModule,
    NzDividerModule,
    NzResultModule,
    NzStatisticModule,
    NzGridModule,
    NzStepsModule,
    NzTimelineModule,
  ],
  templateUrl:'./pathfinder.html',
  styleUrls: ['./pathfinder.scss']
})
export class PathfinderComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();
  
  pathForm: FormGroup;
  sites: SiteRecord[] = [];
  filteredSites: SiteRecord[] = [];
  pathResult: PathResult | null = null;
  finding = false;
  searchAttempted = false;

  constructor(
    private fb: FormBuilder,
    private databaseService: DatabaseService
  ) {
    this.pathForm = this.fb.group({
      source: ['', Validators.required],
      destination: ['', Validators.required],
      algorithm: ['shortest'],
      maxPaths: [],
      networkType: [null]
    });
  }

  ngOnInit() {
    this.loadSites();
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }

  async loadSites() {
    try {
      const currentDb = this.databaseService.getCurrentDatabase();
      if (!currentDb) return;

      this.sites = await this.databaseService.getSites(currentDb);
      this.filteredSites = [...this.sites];
    } catch (error) {
      console.error('Failed to load sites:', error);
    }
  }

  onSearchSites(value: string) {
    const searchTerm = value.toLowerCase();
    this.filteredSites = this.sites.filter(site =>
      site.site_id.toLowerCase().includes(searchTerm) ||
      (site.site_sname && site.site_sname.toLowerCase().includes(searchTerm)) ||
      (site.city && site.city.toLowerCase().includes(searchTerm))
    );
  }

  swapSourceDestination() {
    const source = this.pathForm.get('source')?.value;
    const destination = this.pathForm.get('destination')?.value;
    
    this.pathForm.patchValue({
      source: destination,
      destination: source
    });
  }

  async findPath() {
    if (this.pathForm.invalid) return;

    this.finding = true;
    this.searchAttempted = true;
    this.pathResult = null;

    try {
      const currentDb = this.databaseService.getCurrentDatabase();
      if (!currentDb) {
        throw new Error('No database selected');
      }

      const formValue = this.pathForm.value;
      this.pathResult = await this.databaseService.findShortestPath(
        currentDb,
        formValue.source,
        formValue.destination
      );
    } catch (error) {
      console.error('Failed to find path:', error);
    } finally {
      this.finding = false;
    }
  }

  resetSearch() {
    this.pathResult = null;
    this.searchAttempted = false;
    this.pathForm.reset({
      algorithm: 'shortest',
      maxPaths: 1
    });
  }

  getSiteDisplayName(site: SiteRecord): string {
    const name = site.site_sname || site.site_id;
    const location = site.city ? ` (${site.city})` : '';
    return `${name}${location}`;
  }

  getSiteNameById(siteId: string): string {
    const site = this.sites.find(s => s.site_id === siteId);
    return site?.site_sname || site?.site_id || siteId;
  }

  getSiteLocationById(siteId: string): string {
    const site = this.sites.find(s => s.site_id === siteId);
    return site?.city && site?.country ? `${site.city}, ${site.country}` : 'Unknown Location';
  }

  getSitePlatform(siteId: string): string | null {
    const site = this.sites.find(s => s.site_id === siteId);
    return site?.platform || null;
  }

  getSiteNetwork(siteId: string): string | null {
    const site = this.sites.find(s => s.site_id === siteId);
    return site?.network || null;
  }

  getSitePlatformColor(siteId: string): string {
    const platform = this.getSitePlatform(siteId);
    const colors: { [key: string]: string } = {
      'Fiber': 'blue',
      'Wireless': 'green',
      'Satellite': 'orange',
      'Microwave': 'purple'
    };
    return platform ? colors[platform] || 'default' : 'default';
  }

  getSiteNetworkColor(siteId: string): string {
    const network = this.getSiteNetwork(siteId);
    const colors: { [key: string]: string } = {
      'Core': 'red',
      'Metro': 'blue',
      'Access': 'green',
      'Backbone': 'purple'
    };
    return network ? colors[network] || 'default' : 'default';
  }

  getLinkDistance(index: number): number {
    if (!this.pathResult || index >= this.pathResult.links.length) return 0;
    return this.pathResult.links[index].distance;
  }

  getLinkTypeColor(linkType: string | undefined): string {
    const colors: { [key: string]: string } = {
      'Fiber': 'blue',
      'Microwave': 'green',
      'Satellite': 'orange',
      'Copper': 'volcano'
    };
    return linkType ? colors[linkType] || 'default' : 'default';
  }

  getPathEfficiency(): number {
    if (!this.pathResult) return 0;
    // Calculate efficiency as a percentage (example calculation)
    const efficiency = Math.max(0, 100 - (this.pathResult.hop_count * 10));
    return Math.min(100, efficiency);
  }

  getEfficiencyColor(): string {
    const efficiency = this.getPathEfficiency();
    if (efficiency >= 80) return '#52c41a';
    if (efficiency >= 60) return '#faad14';
    return '#f5222d';
  }

  getStepIcon(index: number): string {
    if (!this.pathResult) return 'environment';
    if (index === 0) return 'play-circle';
    if (index === this.pathResult.path.length - 1) return 'check-circle';
    return 'environment';
  }

  getTimelineColor(index: number): string {
    if (!this.pathResult) return 'blue';
    if (index === 0) return 'green';
    if (index === this.pathResult.path.length - 1) return 'red';
    return 'blue';
  }

  getTimelineIcon(index: number): string {
    if (!this.pathResult) return 'environment';
    if (index === 0) return 'play-circle';
    if (index === this.pathResult.path.length - 1) return 'check-circle';
    return 'environment';
  }
}
