// src/app/pages/analytics/analytics.component.ts
import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NzCardModule } from 'ng-zorro-antd/card';
import { NzStatisticModule } from 'ng-zorro-antd/statistic';
import { NzGridModule } from 'ng-zorro-antd/grid';
import { NzTableModule } from 'ng-zorro-antd/table';
import { NzTagModule } from 'ng-zorro-antd/tag';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzDividerModule } from 'ng-zorro-antd/divider';
import { BaseChartDirective } from 'ng2-charts';
import { ChartConfiguration, ChartType, ChartData } from 'chart.js';
import { DatabaseService } from '../../shared/services/database.service';
import { AnalyticsResult } from '../../shared/interfaces/database.interface';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-analytics',
  standalone: true,
  imports: [
    CommonModule,
    NzCardModule,
    FormsModule,
    NzStatisticModule,
    NzGridModule,
    NzTableModule,
    NzTagModule,
    NzSelectModule,
    NzButtonModule,
    NzIconModule,
    NzDividerModule,
    BaseChartDirective,
  ],
  templateUrl:'./analytics.html',
  styleUrls: ['./analytics.scss']
})
export class AnalyticsComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();
  
  analytics: AnalyticsResult | null = null;
  databases: string[] = [];
  selectedDatabase: string | null = null;
  loading = false;
  networkDistribution: any[] = [];

  // Chart data
  siteTypesChartData: ChartData<'doughnut'> = { labels: [], datasets: [] };
  linkTypesChartData: ChartData<'bar'> = { labels: [], datasets: [] };

  // Chart options
  doughnutChartOptions: ChartConfiguration<'doughnut'>['options'] = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom',
      },
    },
  };

  barChartOptions: ChartConfiguration<'bar'>['options'] = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
      },
    },
  };

  private colorPalette = [
    '#1890ff', '#52c41a', '#faad14', '#f5222d', '#722ed1',
    '#13c2c2', '#eb2f96', '#fa8c16', '#a0d911', '#2f54eb'
  ];

  constructor(private databaseService: DatabaseService) {}

  ngOnInit() {
    this.loadDatabases();
    
    this.databaseService.currentDatabase$
      .pipe(takeUntil(this.destroy$))
      .subscribe(db => {
        if (db) {
          this.selectedDatabase = db;
          this.loadAnalytics();
        }
      });
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }

  async loadDatabases() {
    try {
      this.databases = await this.databaseService.listDatabases();
    } catch (error) {
      console.error('Failed to load databases:', error);
    }
  }

  onDatabaseChange() {
    if (this.selectedDatabase) {
      this.databaseService.setCurrentDatabase(this.selectedDatabase);
    }
  }

  async loadAnalytics() {
    if (!this.selectedDatabase) return;

    this.loading = true;
    try {
      this.analytics = await this.databaseService.getAnalytics(this.selectedDatabase);
      this.processChartData();
      this.processNetworkDistribution();
    } catch (error) {
      console.error('Failed to load analytics:', error);
    } finally {
      this.loading = false;
    }
  }

  refreshAnalytics() {
    this.loadAnalytics();
  }

  private processChartData() {
    if (!this.analytics) return;

    // Site types doughnut chart
    this.siteTypesChartData = {
      labels: this.analytics.site_types.map(item => item || 'Unknown'),
      datasets: [{
        data: this.analytics.site_types.map((item:any) => item),
        backgroundColor: this.colorPalette.slice(0, this.analytics.site_types.length),
        borderWidth: 2,
        borderColor: '#fff'
      }]
    };

    // Link types bar chart
    this.linkTypesChartData = {
      labels: this.analytics.link_types.map(item => item || 'Unknown'),
      datasets: [{
        label: 'Count',
        data: this.analytics.link_types.map((item:any) => item),
        backgroundColor: this.colorPalette.slice(0, this.analytics.link_types.length),
        borderColor: this.colorPalette.slice(0, this.analytics.link_types.length),
        borderWidth: 1
      }]
    };
  }

  private processNetworkDistribution() {
    if (!this.analytics) return;

    // Process network distribution from platforms data
    const networkCounts = new Map<string, number>();
    this.analytics.platforms.forEach(platform => {
      networkCounts.set(platform, 0);
    });

    this.analytics.site_types.forEach(([platform, count]) => {
      if (platform) {
        networkCounts.set(platform, count);
      }
    });

    this.networkDistribution = Array.from(networkCounts.entries()).map(([name, count]) => ({
      name,
      count,
      percentage: this.analytics ? (count / this.analytics.total_sites) * 100 : 0
    }));
  }

  getPlatformColor(platform: any): string {
    const colors: { [key: string]: string } = {
      'Fiber': 'blue',
      'Wireless': 'green',
      'Satellite': 'orange',
      'Microwave': 'purple',
      'Unknown': 'default'
    };
    return colors[platform] || 'default';
  }

  getNetworkColor(network: string): string {
    const colors: { [key: string]: string } = {
      'Core': '#f5222d',
      'Metro': '#1890ff',
      'Access': '#52c41a',
      'Backbone': '#722ed1',
      'Unknown': '#d9d9d9'
    };
    return colors[network] || '#d9d9d9';
  }

  getRandomColor(): string {
    return this.colorPalette[Math.floor(Math.random() * this.colorPalette.length)];
  }
}
