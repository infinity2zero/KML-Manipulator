// src/app/pages/sites/sites.component.ts
import { Component, OnInit, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NzTableModule, NzTableComponent } from 'ng-zorro-antd/table';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzInputNumberModule } from 'ng-zorro-antd/input-number';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { NzModalModule } from 'ng-zorro-antd/modal';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzSpaceModule } from 'ng-zorro-antd/space';
import { NzTagModule } from 'ng-zorro-antd/tag';
import { NzSwitchModule } from 'ng-zorro-antd/switch';
import { NzCardModule } from 'ng-zorro-antd/card';
import { NzDividerModule } from 'ng-zorro-antd/divider';
import { NzDrawerModule } from 'ng-zorro-antd/drawer';
import { NzDescriptionsModule } from 'ng-zorro-antd/descriptions';
import { DatabaseService } from '../../shared/services/database.service';
import { SiteRecord } from '../../shared/interfaces/database.interface';

@Component({
  selector: 'app-sites',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    NzTableModule,
    NzButtonModule,
    NzIconModule,
    NzInputModule,
    NzSelectModule,
    NzModalModule,
    NzFormModule,
    NzSpaceModule,
    NzInputNumberModule,
    NzTagModule,
    NzSwitchModule,
    NzCardModule,
    NzDividerModule,
    NzDrawerModule,
    NzDescriptionsModule,
  ],
  templateUrl:'./sites.html',
  styleUrls: ['./sites.scss']
})
export class SitesComponent implements OnInit {
  @ViewChild('sitesTable', { static: false }) sitesTable!: NzTableComponent<any>;

  sites: SiteRecord[] = [];
  displayData: SiteRecord[] = [];
  loading = false;
  saving = false;
  searchValue = '';
  selectedCountry: string | null = null;
  selectedPlatform: string | null = null;
  pageSize = 50;

  countries: string[] = [];
  platforms: string[] = [];

  showModal = false;
  showDrawer = false;
  editMode = false;
  modalTitle = 'Add New Site';
  selectedSite: SiteRecord | null = null;
  siteForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private databaseService: DatabaseService
  ) {
    this.siteForm = this.createSiteForm();
  }

  ngOnInit() {
    this.loadSites();
  }

  createSiteForm(): FormGroup {
    return this.fb.group({
      site_id: ['', [Validators.required]],
      site_vname: [''],
      site_sname: [''],
      site_lname: [''],
      city: [''],
      country: [''],
      zone: [''],
      platform: [''],
      network: [''],
      latitude: [null],
      longitude: [null],
      is_active: [true],
      is_metro: [false],
      is_ldn: [false],
      is_exitpoint: [false],
      is_zonal_exit: [false],
      is_10g_site: [false],
      is_bypass_site: [false],
      is_capacity_allow: [true],
      is_visible: [true],
      no_of_neighbour: [],
      building_id: [''],
      room: [''],
      floor: [''],
      site_owner: [''],
      created_by: ['']
    });
  }

  async loadSites() {
    this.loading = true;
    try {
      const currentDb = this.databaseService.getCurrentDatabase();
      if (!currentDb) {
        throw new Error('No database selected');
      }

      this.sites = await this.databaseService.getSites(currentDb);
      this.displayData = [...this.sites];
      this.extractFilterOptions();
    } catch (error) {
      console.error('Failed to load sites:', error);
    } finally {
      this.loading = false;
    }
  }

  extractFilterOptions() {
    const countrySet = new Set<string>();
    const platformSet = new Set<string>();

    this.sites.forEach(site => {
      if (site.country) countrySet.add(site.country);
      if (site.platform) platformSet.add(site.platform);
    });

    this.countries = Array.from(countrySet).sort();
    this.platforms = Array.from(platformSet).sort();
  }

  onSearch() {
    this.applyFilters();
  }

  onCountryFilter() {
    this.applyFilters();
  }

  onPlatformFilter() {
    this.applyFilters();
  }

  applyFilters() {
    let filtered = [...this.sites];

    if (this.searchValue) {
      const search = this.searchValue.toLowerCase();
      filtered = filtered.filter(site => 
        site.site_id.toLowerCase().includes(search) ||
        (site.site_sname && site.site_sname.toLowerCase().includes(search)) ||
        (site.city && site.city.toLowerCase().includes(search))
      );
    }

    if (this.selectedCountry) {
      filtered = filtered.filter(site => site.country === this.selectedCountry);
    }

    if (this.selectedPlatform) {
      filtered = filtered.filter(site => site.platform === this.selectedPlatform);
    }

    this.displayData = filtered;
  }

  showAddModal() {
    this.editMode = false;
    this.modalTitle = 'Add New Site';
    this.siteForm.reset();
    this.siteForm.patchValue({
      is_active: true,
      is_visible: true,
      is_capacity_allow: true,
      no_of_neighbour: 0
    });
    this.showModal = true;
  }

  editSite(site: SiteRecord) {
    this.editMode = true;
    this.modalTitle = 'Edit Site';
    this.siteForm.patchValue(site);
    this.showModal = true;
  }

  viewSite(site: SiteRecord) {
    this.selectedSite = site;
    this.showDrawer = true;
  }

  async saveSite() {
    if (this.siteForm.invalid) {
      Object.values(this.siteForm.controls).forEach(control => {
        control.markAsDirty();
        control.updateValueAndValidity();
      });
      return;
    }

    this.saving = true;
    try {
      const currentDb = this.databaseService.getCurrentDatabase();
      if (!currentDb) {
        throw new Error('No database selected');
      }

      const siteData = this.siteForm.value;
      // await this.databaseService.updateSite(currentDb, siteData);
      
      this.closeModal();
      await this.loadSites();
    } catch (error) {
      console.error('Failed to save site:', error);
    } finally {
      this.saving = false;
    }
  }

  async deleteSite(site: SiteRecord) {
    // Implement delete functionality
    console.log('Delete site:', site);
  }

  closeModal() {
    this.showModal = false;
    this.siteForm.reset();
  }

  refreshData() {
    this.loadSites();
  }

  getPlatformColor(platform: string | null): string {
    const colors: { [key: string]: string } = {
      'Fiber': 'blue',
      'Wireless': 'green',
      'Satellite': 'orange',
      'Microwave': 'purple'
    };
    return platform ? colors[platform] || 'default' : 'default';
  }

  getNetworkColor(network: string | null): string {
    const colors: { [key: string]: string } = {
      'Core': 'red',
      'Metro': 'blue',
      'Access': 'green',
      'Backbone': 'purple'
    };
    return network ? colors[network] || 'default' : 'default';
  }
}
