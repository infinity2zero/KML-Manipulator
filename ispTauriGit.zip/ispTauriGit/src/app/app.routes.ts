import { Routes } from "@angular/router";

export const routes: Routes = [
    {path: '', redirectTo: 'main', pathMatch: 'full'},
    {path: 'main', loadComponent: () => import('./core/layout/layout').then(m => m.MainLayoutComponent),
        children: [
            {path:'databases',loadComponent:()=> import('./features/database/database').then(m=>m.DatabasesComponent)},
            {path:'test',loadComponent:()=> import('../spatial-test/spatial-test').then(m=>m.SpatialTestComponent)},
        ]
    },
];
