import { Component, HostListener, OnInit } from "@angular/core";
import { RouterOutlet } from "@angular/router";
import { invoke } from "@tauri-apps/api/core";
import { NzIconModule } from 'ng-zorro-antd/icon';


@Component({
  selector: "app-root",
  imports: [RouterOutlet, NzIconModule],
  templateUrl: "./app.component.html",
  styleUrl: "./app.component.scss",
})
export class AppComponent implements OnInit {
  greetingMessage = "";

  greet(event: SubmitEvent, name: string): void {
    event.preventDefault();

    invoke<string>("greet", { name }).then((text) => {
      this.greetingMessage = text;
    });

    invoke("test_spatialite_connection")
      .then(result => console.log("Spatialite test:", result))
      .catch(e => console.error("Test failed:", e));
  }

   windowWidth: number = window.innerWidth;
  windowHeight: number = window.innerHeight;

  // Listen to window resize events
  @HostListener('window:resize', ['$event'])
  onResize(event: Event) {
    this.windowWidth = window.innerWidth;
    this.windowHeight = window.innerHeight;
    // Trigger any additional logic or change detection here
    this.handleResize();
  }

  handleResize() {
    // Add any logic needed on resize, e.g., adjust layout or refresh visuals
    // For example, update CSS variables or trigger Angular change detection
    console.log(`Window resized to ${this.windowWidth}x${this.windowHeight}`);
  }


  ngOnInit() {
    this.handleResize();
  }
}
