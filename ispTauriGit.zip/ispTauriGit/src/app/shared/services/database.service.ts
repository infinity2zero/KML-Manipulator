// src/app/shared/services/database.service.ts
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { invoke } from '@tauri-apps/api/core';
import { listen } from '@tauri-apps/api/event';

import { SiteRecord, LinkRecord, AnalyticsResult, PathResult, DatabaseInfo } from '../interfaces/database.interface';

export interface ImportFromFilesRequest {
  database_name: string;
  sites_csv_path?: string;
  links_csv_path?: string;
  kml_zip_path?: string;
}

@Injectable({
  providedIn: 'root'
})
export class DatabaseService {
  private currentDatabaseSubject = new BehaviorSubject<string | null>(null);
  public currentDatabase$ = this.currentDatabaseSubject.asObservable();

  constructor() {
    const savedDb = localStorage.getItem('currentDatabase');
    if (savedDb) {
      this.currentDatabaseSubject.next(savedDb);
    }
  }

  getCurrentDatabase(): string | null {
    return this.currentDatabaseSubject.value;
  }

  setCurrentDatabase(dbName: string): void {
    this.currentDatabaseSubject.next(dbName);
    if (dbName) {
      localStorage.setItem('currentDatabase', dbName);
    } else {
      localStorage.removeItem('currentDatabase');
    }
  }

  // Database Management
  async createDatabase(name: string, description?: string): Promise<any> {
    return await invoke('create_database', {
      request: { name, description }
    });
  }

  async listDatabases(): Promise<string[]> {
    return await invoke('list_databases');
  }

  async deleteDatabase(dbName: string): Promise<string> {
    return await invoke('delete_database', { dbName });
  }

  async getDatabaseInfo(dbName: string): Promise<DatabaseInfo> {
    return await invoke('get_database_info', { dbName });
  }

  // Import from file paths (new method)
  async importFromFiles(dbName: string, filePaths: any): Promise<string> {
    const request: ImportFromFilesRequest = {
      database_name: dbName,
      sites_csv_path: filePaths.sites_csv,
      links_csv_path: filePaths.links_csv,
      kml_zip_path: filePaths.kml_zip
    };
    console.log('Filese importing',request);
    
    return await invoke('import_from_files', { request });
    
  }


  // Existing methods...
  async getSites(dbName: string): Promise<SiteRecord[]> {
    return await invoke('get_all_sites', { dbName });
  }

  async getLinks(dbName: string): Promise<LinkRecord[]> {
    return await invoke('get_all_links', { dbName });
  }

  async getAnalytics(dbName: string): Promise<AnalyticsResult> {
    return await invoke('get_analytics', { dbName });
  }

  async findShortestPath(dbName: string, source: string, destination: string): Promise<PathResult> {
    return await invoke('find_shortest_path', { dbName, source, destination });
  }

  async getSitesPbf(dbName: string, z: number, x: number, y: number): Promise<Uint8Array> {
    return await invoke('get_sites_pbf', { dbName, z, x, y });
  }

  async getLinksPbf(dbName: string, z: number, x: number, y: number): Promise<Uint8Array> {
    return await invoke('get_links_pbf', { dbName, z, x, y });
  }
}
