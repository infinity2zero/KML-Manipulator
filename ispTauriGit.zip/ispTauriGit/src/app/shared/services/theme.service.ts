// src/app/shared/services/theme.service.ts
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ThemeService {
  private isDarkThemeSubject = new BehaviorSubject<boolean>(false);
  public isDarkTheme$ = this.isDarkThemeSubject.asObservable();

  constructor() {
    // Load theme from localStorage or system preference
    const savedTheme = localStorage.getItem('theme');
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    
    const isDark = savedTheme ? savedTheme === 'dark' : prefersDark;
    this.setTheme(isDark);

    // Listen for system theme changes
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
      if (!localStorage.getItem('theme')) {
        this.setTheme(e.matches);
      }
    });
  }

  toggleTheme(): void {
    this.setTheme(!this.isDarkThemeSubject.value);
  }

  private setTheme(isDark: boolean): void {
    this.isDarkThemeSubject.next(isDark);
    localStorage.setItem('theme', isDark ? 'dark' : 'light');
    
    const htmlElement = document.documentElement;
    if (isDark) {
      htmlElement.classList.add('dark');
    } else {
      htmlElement.classList.remove('dark');
    }

    // Update CSS custom properties for theming
    this.updateCSSVariables(isDark);
  }

  private updateCSSVariables(isDark: boolean): void {
    const root = document.documentElement;
    
    if (isDark) {
      // Dark theme variables
      root.style.setProperty('--app-primary', '#1677ff');
      root.style.setProperty('--app-secondary', '#8c8c8c');
      root.style.setProperty('--app-background', '#141414');
      root.style.setProperty('--app-surface', '#1f1f1f');
      root.style.setProperty('--app-text', '#ffffff');
      root.style.setProperty('--app-textSecondary', '#a6a6a6');
      root.style.setProperty('--app-border', '#434343');
      root.style.setProperty('--app-accent', '#13c2c2');
      root.style.setProperty('--app-success', '#52c41a');
      root.style.setProperty('--app-warning', '#faad14');
      root.style.setProperty('--app-danger', '#ff4d4f');
      root.style.setProperty('--app-info', '#13c2c2');
    } else {
      // Light theme variables
      root.style.setProperty('--app-primary', '#1677ff');
      root.style.setProperty('--app-secondary', '#8c8c8c');
      root.style.setProperty('--app-background', '#ffffff');
      root.style.setProperty('--app-surface', '#fafafa');
      root.style.setProperty('--app-text', '#000000');
      root.style.setProperty('--app-textSecondary', '#666666');
      root.style.setProperty('--app-border', '#d9d9d9');
      root.style.setProperty('--app-accent', '#13c2c2');
      root.style.setProperty('--app-success', '#52c41a');
      root.style.setProperty('--app-warning', '#faad14');
      root.style.setProperty('--app-danger', '#ff4d4f');
      root.style.setProperty('--app-info', '#13c2c2');
    }
  }
}
