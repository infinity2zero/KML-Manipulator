// src/app/shared/interfaces/database.interface.ts
export interface SiteRecord {
  site_id: string;
  site_vname?: string;
  site_sname?: string;
  site_lname?: string;
  is_metro: boolean;
  is_ldn: boolean;
  is_active: boolean;
  city?: string;
  is_exitpoint: boolean;
  no_of_neighbour: number;
  building_id?: string;
  xng_site_name?: string;
  site_owner?: string;
  created_on?: string;
  created_by?: string;
  is_visible: boolean;
  zone?: string;
  is_zonal_exit: boolean;
  zonal_neighbour?: string;
  kmz_lib_no?: string;
  country?: string;
  is_capacity_allow: boolean;
  err_code?: string;
  room?: string;
  floor?: string;
  is_10g_site: boolean;
  is_bypass_site: boolean;
  tid_id?: string;
  arch_type?: string;
  platform?: string;
  network?: string;
  geometry_wkt?: string;
  latitude?: number;
  longitude?: number;
}

export interface LinkRecord {
  link_id: string;
  site_a: string;
  site_b: string;
  city?: string;
  distance: number;
  platency_t_100?: number;
  is_active: boolean;
  is_ldn: boolean;
  is_metro: boolean;
  is_common_wire: boolean;
  wire_code?: string;
  xng_wms_id?: string;
  kmz_lib_no?: string;
  fiber_owner?: string;
  is_virtual: boolean;
  created_on?: string;
  created_by?: string;
  zone?: string;
  is_subsea_link: boolean;
  zonea?: string;
  zoneb?: string;
  link_name?: string;
  country?: string;
  countrya?: string;
  countryb?: string;
  m_latency?: number;
  err_code?: string;
  is_visible: boolean;
  link_type?: string;
  is_capacityavailable: boolean;
  fao?: string;
  physical_path?: string;
  platform?: string;
  network?: string;
  interconnect_links?: string;
  geometry_wkt?: string;
}

export interface AnalyticsResult {
  total_sites: number;
  total_links: number;
  countries: string[];
  cities: string[];
  platforms: string[];
  networks: string[];
  site_types: [string, number][];
  link_types: [string, number][];
  avg_distance: number;
  max_distance: number;
  min_distance: number;
}

export interface PathResult {
  path: string[];
  total_distance: number;
  total_latency: number;
  hop_count: number;
  sites: SiteRecord[];
  links: LinkRecord[];
}

export interface DatabaseInfo {
  name: string;
  site_count: number;
  link_count: number;
  created_at: string;
  size_bytes: number;
}
