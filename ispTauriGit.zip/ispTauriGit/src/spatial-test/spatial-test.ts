import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { invoke } from "@tauri-apps/api/core";

@Component({
  selector: 'app-spatial-test',
  imports: [CommonModule],
  template: `
    <div style="padding: 20px;">
      <h2>🗺️ Spatial Database Test Suite</h2>
      
      <div style="margin: 20px 0;">
        <button (click)="runComprehensiveTest()" 
                [disabled]="loading"
                style="margin: 5px; padding: 10px 20px; font-size: 16px;">
          🧪 Run Comprehensive Test
        </button>
        
        <button (click)="testSpatialOperations()" 
                [disabled]="loading"
                style="margin: 5px; padding: 10px 20px; font-size: 16px;">
          ⚙️ Test Spatial Operations
        </button>
        
        <button (click)="createTestDatabase()" 
                [disabled]="loading"
                style="margin: 5px; padding: 10px 20px; font-size: 16px;">
          📊 Create Test Database
        </button>
      </div>
      
      <div *ngIf="loading" style="color: blue;">
        ⏳ Running test...
      </div>
      
      <div *ngIf="result" 
           style="background: #f0f0f0; padding: 15px; margin: 10px 0; border-radius: 5px;">
        <h3>✅ Test Results:</h3>
        <pre>{{ result | json }}</pre>
      </div>
      
      <div *ngIf="error" 
           style="background: #ffebee; color: #c62828; padding: 15px; margin: 10px 0; border-radius: 5px;">
        <h3>❌ Error:</h3>
        <pre>{{ error }}</pre>
      </div>
    </div>
  `
})
export class SpatialTestComponent {
  loading = false;
  result: any = null;
  error: string = '';

  async runComprehensiveTest() {
    this.loading = true;
    this.error = '';
    this.result = null;
    
    try {
      const result = await invoke('comprehensive_spatial_test');
      this.result = result;
      console.log('Comprehensive test result:', result);
    } catch (error) {
      this.error = String(error);
      console.error('Test failed:', error);
    } finally {
      this.loading = false;
    }
  }

  async testSpatialOperations() {
    this.loading = true;
    this.error = '';
    this.result = null;
    
    try {
      const result = await invoke('test_spatial_operations');
      this.result = { message: result };
      console.log('Spatial operations test:', result);
    } catch (error) {
      this.error = String(error);
      console.error('Test failed:', error);
    } finally {
      this.loading = false;
    }
  }

  async createTestDatabase() {
    this.loading = true;
    this.error = '';
    this.result = null;
    
    try {
      const result = await invoke('create_database_from_test_data', { 
        dbName: 'test_network_' + Date.now() 
      });
      this.result = { message: result };
      console.log('Database creation test:', result);
    } catch (error) {
      this.error = String(error);
      console.error('Test failed:', error);
    } finally {
      this.loading = false;
    }
  }
}
