//build.rs
use std::env;
use std::path::{Path, PathBuf};

fn main() {
    // Run tauri-build
    tauri_build::build();
    
    // Get build information
    let target = env::var("TARGET").unwrap_or_else(|_| "unknown".to_string());
    let profile = env::var("PROFILE").unwrap_or_else(|_| "unknown".to_string());
    let out_dir = env::var("OUT_DIR").unwrap_or_else(|_| "unknown".to_string());
    
    println!("cargo:warning=Building for target: {}", target);
    println!("cargo:warning=Build profile: {}", profile);
    println!("cargo:warning=Output directory: {}", out_dir);
    
    // Check if resources directory exists and log its contents
    check_resources_directory();
    
    // Print library search paths for debugging
    print_library_search_paths();
    
    // Set up platform-specific library paths if needed
    setup_platform_libraries(&target);
}

fn check_resources_directory() {
    let manifest_dir = env::var("CARGO_MANIFEST_DIR").unwrap();
    let resources_path = Path::new(&manifest_dir).join("resources");
    
    println!("cargo:warning=Checking resources directory: {:?}", resources_path);
    
    if resources_path.exists() {
        println!("cargo:warning=Resources directory exists");
        
        // Check libs subdirectory
        let libs_path = resources_path.join("libs");
        if libs_path.exists() {
            println!("cargo:warning=Libs directory exists");
            
            // Check platform-specific directories
            let platforms = ["win-x64", "mac-x64", "mac-arm64", "linux-x64"];
            for platform in &platforms {
                let platform_path = libs_path.join(platform);
                if platform_path.exists() {
                    println!("cargo:warning=Platform directory exists: {}", platform);
                    
                    // List files in platform directory
                    if let Ok(entries) = std::fs::read_dir(&platform_path) {
                        let files: Vec<_> = entries
                            .filter_map(|e| e.ok())
                            .map(|e| e.file_name())
                            .filter_map(|name| name.to_str().map(String::from))
                            .collect();
                        
                        if !files.is_empty() {
                            println!("cargo:warning=Files in {}: {:?}", platform, files);
                        } else {
                            println!("cargo:warning=No files found in {}", platform);
                        }
                    }
                } else {
                    println!("cargo:warning=Platform directory missing: {}", platform);
                }
            }
        } else {
            println!("cargo:warning=Libs directory does not exist");
        }
    } else {
        println!("cargo:warning=Resources directory does not exist");
        println!("cargo:warning=Expected location: {:?}", resources_path);
    }
}

fn print_library_search_paths() {
    // Print rustc library search paths
    if let Ok(target_dir) = env::var("CARGO_TARGET_DIR") {
        println!("cargo:warning=Target directory: {}", target_dir);
    }
    
    if let Ok(deps_dir) = env::var("DEPS") {
        println!("cargo:warning=Dependencies directory: {}", deps_dir);
    }
    
    // Print system library paths that might be relevant
    if cfg!(target_os = "windows") {
        if let Ok(system_root) = env::var("SYSTEMROOT") {
            println!("cargo:warning=Windows system root: {}", system_root);
        }
    }
}

fn setup_platform_libraries(target: &str) {
    println!("cargo:warning=Setting up libraries for target: {}", target);
    
    // Platform-specific library setup
    if target.contains("windows") {
        setup_windows_libraries();
    } else if target.contains("apple") {
        setup_macos_libraries();
    } else if target.contains("linux") {
        setup_linux_libraries();
    }
}

fn setup_windows_libraries() {
    println!("cargo:warning=Setting up Windows-specific libraries");
    
    // Check for Windows redistributables that might be needed
    let manifest_dir = env::var("CARGO_MANIFEST_DIR").unwrap();
    let libs_path = PathBuf::from(&manifest_dir).join("resources/libs/win-x64");
    
    if libs_path.exists() {
        // Add the library directory to the path for finding DLLs at runtime
        println!("cargo:rustc-link-search=native={}", libs_path.display());
        
        // Check for specific required libraries
        let required_libs = ["mod_spatialite.dll", "spatialite.dll"];
        for lib in &required_libs {
            let lib_path = libs_path.join(lib);
            if lib_path.exists() {
                println!("cargo:warning=Found Windows library: {:?}", lib_path);
            } else {
                println!("cargo:warning=Missing Windows library: {:?}", lib_path);
            }
        }
    }
}

fn setup_macos_libraries() {
    println!("cargo:warning=Setting up macOS-specific libraries");
    
    let manifest_dir = env::var("CARGO_MANIFEST_DIR").unwrap();
    let target = env::var("TARGET").unwrap_or_default();
    
    let arch_dir = if target.contains("aarch64") {
        "mac-arm64"
    } else {
        "mac-x64"
    };
    
    let libs_path = PathBuf::from(&manifest_dir).join("resources/libs").join(arch_dir);
    
    if libs_path.exists() {
        println!("cargo:rustc-link-search=native={}", libs_path.display());
        
        // Check for macOS dylib files
        let required_libs = ["mod_spatialite.dylib", "libspatialite.dylib"];
        for lib in &required_libs {
            let lib_path = libs_path.join(lib);
            if lib_path.exists() {
                println!("cargo:warning=Found macOS library: {:?}", lib_path);
            } else {
                println!("cargo:warning=Missing macOS library: {:?}", lib_path);
            }
        }
    }
}

fn setup_linux_libraries() {
    println!("cargo:warning=Setting up Linux-specific libraries");
    
    let manifest_dir = env::var("CARGO_MANIFEST_DIR").unwrap();
    let libs_path = PathBuf::from(&manifest_dir).join("resources/libs/linux-x64");
    
    if libs_path.exists() {
        println!("cargo:rustc-link-search=native={}", libs_path.display());
        
        // Check for Linux .so files
        let required_libs = ["mod_spatialite.so", "libspatialite.so"];
        for lib in &required_libs {
            let lib_path = libs_path.join(lib);
            if lib_path.exists() {
                println!("cargo:warning=Found Linux library: {:?}", lib_path);
            } else {
                println!("cargo:warning=Missing Linux library: {:?}", lib_path);
            }
        }
    }
}