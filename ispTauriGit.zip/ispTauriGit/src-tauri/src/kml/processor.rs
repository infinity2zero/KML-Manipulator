use anyhow::{Context, Result};
use rayon::prelude::*;
use zip::ZipArchive;
use std::io::{Cursor, Read};
use base64::{engine::general_purpose, Engine as _};
use crate::kml::parser::{extract_wkts_from_kml, KmlGeometryData};

pub fn extract_geometries_from_zip(base64: &str) -> Result<Vec<KmlGeometryData>> {
    // Decode base64
    let zip_bytes = general_purpose::STANDARD
        .decode(base64)
        .context("Failed to decode base64 KMZ")?;

    // Open ZIP archive
    let mut archive = ZipArchive::new(Cursor::new(zip_bytes))
        .context("Failed to read ZIP archive")?;

    let mut kmls = Vec::new();
    println!("📦 Total files in ZIP: {}", archive.len());

    for i in 0..archive.len() {
        let mut file = archive.by_index(i).context("Failed to read ZIP entry")?;
        let name = file.name().to_string();
        println!("➡️ Found file in ZIP before .kml check: {}", name);

        // Skip directories
        if file.is_dir() {
            println!("   ⏩ Skipping directory: {}", name);
            continue;
        }

        let lower = name.to_lowercase();

        if lower.ends_with(".kml") {
            println!("   ✅ KML detected: {}", name);

            // Read as raw bytes to avoid UTF-8 issues
            let mut buf = Vec::new();
            file.read_to_end(&mut buf).context("Failed to read KML file")?;

            // Decode (lossy if invalid UTF-8)
            let xml = String::from_utf8_lossy(&buf).to_string();

            println!("   📄 KML size: {} bytes", xml.len());
            kmls.push((name, xml));
        } else {
            println!("   ❌ Not a KML file, skipping: {}", name);
        }

        println!("   📊 Total KML files collected so far: {}", kmls.len());
    }

    println!("✅ Finished scanning ZIP. Total KML files collected: {}", kmls.len());

    // Process KMLs in parallel
    let geometries: Vec<KmlGeometryData> = kmls
        .into_par_iter()
        .flat_map(|(filename, xml)| {
            let lib_no = filename
                .rsplit('/')
                .next()
                .unwrap_or(&filename)
                .replace(".kml", "");

            println!("🔍 Processing KML file: {} with lib_no: {}", filename, lib_no);

            match extract_wkts_from_kml(&xml, &lib_no) {
                Ok(data) => {
                    println!("   ✅ Parsed {} geometries from {}", data.len(), filename);
                    data
                }
                Err(e) => {
                    println!("   ⚠️ Failed to parse {}: {}", filename, e);
                    Vec::new()
                }
            }
        })
        .collect();

    println!("🏁 Total geometries extracted: {}", geometries.len());

    Ok(geometries)
}

