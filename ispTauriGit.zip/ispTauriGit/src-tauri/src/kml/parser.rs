
use crate::kml::sanitize::sanitize_xml; // Adjust if path differs
use anyhow::Result;
use geo_types::Geometry;
use kml::types::Placemark;
use kml::{Kml, KmlReader};
use wkt::ToWkt;

#[derive(Debug)]
pub struct KmlGeometryData {
    pub lib_no: String,
    pub geometry_type: String,
    pub wkt: String,
}

pub fn extract_wkts_from_kml(xml: &str, lib_no: &str) -> Result<Vec<KmlGeometryData>> {
    let sanitized = sanitize_xml(xml); // Clean up invalid characters
    let mut reader = KmlReader::from_string(&sanitized);
    let kml: Kml = reader.read()?; // Parses to the Kml enum

    println!("Parsing KML for lib_no: {}", lib_no);
    println!("Top-level KML variant: {:?}", std::mem::discriminant(&kml));

    // Recursively extract Placemarks
    let placemarks = extract_placemarks_from_kml(&kml);
    println!("Found {} placemarks in lib_no: {}", placemarks.len(), lib_no);

    let mut results = Vec::new();

    for placemark in placemarks {
        if let Some(geom) = &placemark.geometry {
            let g: Geometry<f64> = geom.clone().try_into()?;
            let geom_type = match &g {
                Geometry::Point(_) => "Point",
                Geometry::MultiPoint(_) => "MultiPoint",
                Geometry::Line(_) => "Line",
                Geometry::LineString(_) => "LineString",
                Geometry::MultiLineString(_) => "MultiLineString",
                Geometry::Polygon(_) => "Polygon",
                Geometry::MultiPolygon(_) => "MultiPolygon",
                Geometry::GeometryCollection(_) => "GeometryCollection",
                _ => "Unknown",
            }
            .to_string();

            let wkt = g.to_wkt().to_string();
            results.push(KmlGeometryData {
                lib_no: lib_no.to_string(),
                geometry_type: geom_type,
                wkt,
            });
        }
    }

    Ok(results)
}

fn extract_placemarks_from_kml(kml: &Kml) -> Vec<Placemark> {
    let mut placemarks = Vec::new();

    match kml {
        Kml::KmlDocument(doc) => {
            println!("Recursing into KmlDocument with {} elements", doc.elements.len());
            for element in &doc.elements {
                placemarks.extend(extract_placemarks_from_kml(element));
            }
        }
        Kml::Document { elements, .. } | Kml::Folder { elements, .. } => {
            println!("Recursing into container with {} elements", elements.len());
            for element in elements {
                placemarks.extend(extract_placemarks_from_kml(element));
            }
        }
        Kml::Placemark(p) => {
            println!("Found Placemark: {:?}", p.name);
            placemarks.push(p.clone());
        }
        _ => {}
    }

    placemarks
}

