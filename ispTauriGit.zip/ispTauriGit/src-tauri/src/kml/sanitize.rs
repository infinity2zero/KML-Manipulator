// use regex::Regex;
// pub fn sanitize_xml(raw: &str) -> String {
//     // Step 1: Replace problematic symbols
//     let cleaned = raw
//         .replace('©', "(c)")
//         .replace('\u{00A9}', "(c)")    // Unicode for ©
//         .replace('\u{FFFD}', "")       // Unicode replacement char (�)
//         .replace('\u{0000}', "")       // Null character
//         .replace('\u{0001}', "")
//         .replace('\u{0002}', "")
//         .replace('\u{0003}', "");

//     // Step 2: Remove xmlns declarations (e.g. xmlns="..." or xmlns:kml="...")
//     let xmlns_pattern = Regex::new(r#" ?xmlns(:\w+)?="[^"]*""#).unwrap();
//     let no_namespaces = xmlns_pattern.replace_all(&cleaned, "");

//     no_namespaces.to_string()
// }
use regex::Regex;

pub fn sanitize_xml(raw: &str) -> String {
    let cleaned = raw
        .replace('©', "(c)")
        .replace('\u{00A9}', "(c)")
        .replace('\u{FFFD}', "")
        .replace('\u{0000}', "")
        .replace('\u{0001}', "")
        .replace('\u{0002}', "")
        .replace('\u{0003}', "");

    let re: Regex = Regex::new(r"[^\x09\x0A\x0D\x20-\x7E]").unwrap();
    re.replace_all(&cleaned, "").to_string()
}
