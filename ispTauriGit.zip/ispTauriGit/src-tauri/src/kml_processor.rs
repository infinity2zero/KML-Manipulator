// // src-tauri/src/kml_processor.rs
// use anyhow::{Context, Result};
// use quick_xml::Reader;
// use quick_xml::events::Event;
// use std::io::{Cursor, Read};
// use zip::ZipArchive;
// use base64::{engine::general_purpose, Engine as _};
// use log::{debug, info, warn, error};

// use crate::spatial_db::{SiteRecord, LinkRecord};

// #[derive(Debug, Clone)]
// pub struct KmlGeometryData {
//     pub kmz_lib_no: String,
//     pub wkt: String,
//     pub geometry_type: String, // "POINT" or "LINESTRING"
// }

// pub struct KmlProcessor;

// impl KmlProcessor {
//     /// Extract all geometries from a base64-encoded ZIP/KMZ file
//     pub fn extract_geometries_from_zip(base64: &str) -> Result<Vec<KmlGeometryData>> {
//         println!("🗂️ Extracting KML geometries from ZIP archive");
        
//         let zip_bytes = general_purpose::STANDARD
//             .decode(base64)
//             .context("Base64 decode failed")?;
            
//         let mut archive = ZipArchive::new(Cursor::new(zip_bytes))
//             .context("Opening ZIP archive failed")?;
            
//         let mut results = Vec::new();

//         println!("Processing {} files in ZIP archive", archive.len());

//         for i in 0..archive.len() {
//             let mut file = archive.by_index(i)
//                 .context("Reading ZIP entry failed")?;
                
//             let filename = file.name().to_string();
            
//             if filename.to_lowercase().ends_with(".kml") {
//                 println!("📄 Processing KML file: {}", filename);
                
//                 let mut xml = String::new();
//                 file.read_to_string(&mut xml)
//                     .context("Reading KML failed")?;
                    
//                 let lib_no = filename
//                     .rsplit('/')
//                     .next()
//                     .unwrap_or(&filename)
//                     .trim_end_matches(".kml")
//                     .trim_end_matches(".KML")
//                     .to_string();
                
//                 match Self::parse_all_wkts(&xml, &lib_no) {
//                     Ok(geometries) => {
//                         debug!("Extracted {} geometries from {}", geometries.len(), filename);
//                         results.extend(geometries);
//                     }
//                     Err(e) => {
//                         warn!("Failed to parse KML file {}: {}", filename, e);
//                     }
//                 }
//             }
//         }
        
//         println!("✅ Extracted {} total geometries from ZIP archive", results.len());
//         Ok(results)
//     }

//     /// Parse all Point and LineString elements from KML into WKT
//     fn parse_all_wkts(xml: &str, lib_no: &str) -> Result<Vec<KmlGeometryData>> {
//         let mut reader = Reader::from_str(xml);
//         reader.trim_text(true);
//         let mut buf = Vec::new();
//         let mut geometries = Vec::new();

//         let mut in_point = false;
//         let mut in_linestring = false;
//         let mut coord_text = String::new();

//         loop {
//             match reader.read_event_into(&mut buf) {
//                 Ok(Event::Start(e)) => match e.local_name().as_ref() {
//                     b"Point" => {
//                         in_point = true;
//                         debug!("Found Point geometry in {}", lib_no);
//                     }
//                     b"LineString" => {
//                         in_linestring = true;
//                         debug!("Found LineString geometry in {}", lib_no);
//                     }
//                     _ => {}
//                 },
//                 Ok(Event::Text(e)) if in_point || in_linestring => {
//                     coord_text = e.unescape()?.to_string();
//                 }
//                 Ok(Event::End(e)) => match e.local_name().as_ref() {
//                     b"Point" if in_point => {
//                         in_point = false;
//                         match Self::first_coord(&coord_text) {
//                             Ok((lon, lat)) => {
//                                 let wkt = format!("POINT({} {})", lon, lat);
//                                 geometries.push(KmlGeometryData {
//                                     kmz_lib_no: lib_no.to_string(),
//                                     wkt,
//                                     geometry_type: "POINT".to_string(),
//                                 });
//                                 debug!("Created Point WKT for {}: POINT({} {})", lib_no, lon, lat);
//                             }
//                             Err(e) => {
//                                 warn!("Failed to parse Point coordinates in {}: {}", lib_no, e);
//                             }
//                         }
//                     }
//                     b"LineString" if in_linestring => {
//                         in_linestring = false;
//                         let coords: Vec<String> = coord_text
//                             .split_whitespace()
//                             .filter_map(|pair| {
//                                 let parts: Vec<&str> = pair.split(',').collect();
//                                 if parts.len() >= 2 {
//                                     // Fixed: Access individual elements, not the whole Vec
//                                     Some(format!("{} {}", parts[0], parts[1]))
//                                 } else {
//                                     None
//                                 }
//                             })
//                             .collect();
                        
//                         if !coords.is_empty() {
//                             let wkt = format!("LINESTRING({})", coords.join(", "));
//                             geometries.push(KmlGeometryData {
//                                 kmz_lib_no: lib_no.to_string(),
//                                 wkt,
//                                 geometry_type: "LINESTRING".to_string(),
//                             });
//                             debug!("Created LineString WKT for {} with {} points", lib_no, coords.len());
//                         }
//                     }
//                     _ => {}
//                 },
//                 Ok(Event::Eof) => break,
//                 Err(e) => return Err(e.into()),
//                 _ => {}
//             }
//             buf.clear();
//         }

//         Ok(geometries)
//     }

//     /// Parse the first coordinate from a coordinate string
//     fn first_coord(s: &str) -> Result<(f64, f64)> {
//         let first = s
//             .split_whitespace()
//             .next()
//             .context("No coordinates found")?;
            
//         let parts: Vec<&str> = first.split(',').collect();
//         if parts.len() < 2 {
//             anyhow::bail!("Invalid coordinate pair: {}", first);
//         }
        
//         // Fixed: Access individual elements and parse them
//         let lon: f64 = parts[0].parse()
//             .context("Parsing longitude failed")?;
//         let lat: f64 = parts[1].parse()
//             .context("Parsing latitude failed")?;
            
//         Ok((lon, lat))
//     }

//     /// Apply Point geometries to site records by matching KMZ_LIB_NO
//     pub fn apply_geometries_to_sites(
//         sites: &mut Vec<SiteRecord>, 
//         geometries: &[KmlGeometryData]
//     ) -> usize {
//         println!("🔗 Applying geometries to {} sites", sites.len());
//         let mut matched_count = 0;

//         for site in sites.iter_mut() {
//             if let Some(ref kmz_lib_no) = site.kmz_lib_no {
//                 // Find matching Point geometry
//                 if let Some(geometry) = geometries.iter().find(|g| 
//                     g.kmz_lib_no == *kmz_lib_no && g.geometry_type == "POINT"
//                 ) {
//                     site.geometry_wkt = Some(geometry.wkt.clone());
                    
//                     // Also extract coordinates for lat/lon fields if not already set
//                     if site.latitude.is_none() || site.longitude.is_none() {
//                         if let Ok((lon, lat)) = Self::extract_point_coords(&geometry.wkt) {
//                             site.latitude = Some(lat);
//                             site.longitude = Some(lon);
//                         }
//                     }
                    
//                     matched_count += 1;
//                     debug!("✓ Applied geometry to site {}: {}", site.site_id, geometry.wkt);
//                 }
//             }
//         }

//         println!("✅ Applied geometries to {}/{} sites", matched_count, sites.len());
//         matched_count
//     }

//     /// Apply LineString geometries to link records by matching KMZ_LIB_NO
//     pub fn apply_geometries_to_links(
//         links: &mut Vec<LinkRecord>, 
//         geometries: &[KmlGeometryData]
//     ) -> usize {
//         println!("🔗 Applying geometries to {} links", links.len());
//         let mut matched_count = 0;

//         for link in links.iter_mut() {
//             if let Some(ref kmz_lib_no) = link.kmz_lib_no {
//                 // Find matching LineString geometry
//                 if let Some(geometry) = geometries.iter().find(|g| 
//                     g.kmz_lib_no == *kmz_lib_no && g.geometry_type == "LINESTRING"
//                 ) {
//                     link.geometry_wkt = Some(geometry.wkt.clone());
//                     matched_count += 1;
//                     debug!("✓ Applied geometry to link {}: {}", link.link_id, geometry.wkt);
//                 }
//             }
//         }

//         println!("✅ Applied geometries to {}/{} links", matched_count, links.len());
//         matched_count
//     }

//     /// Extract longitude and latitude from a POINT WKT string
//     fn extract_point_coords(wkt: &str) -> Result<(f64, f64)> {
//         // Parse "POINT(lon lat)" format
//         if let Some(coords_part) = wkt.strip_prefix("POINT(").and_then(|s| s.strip_suffix(")")) {
//             let parts: Vec<&str> = coords_part.split_whitespace().collect();
//             if parts.len() >= 2 {
//                 // Fixed: Access individual elements and parse them
//                 let lon: f64 = parts[0].parse().context("Invalid longitude in WKT")?;
//                 let lat: f64 = parts[1].parse().context("Invalid latitude in WKT")?;
//                 return Ok((lon, lat));
//             }
//         }
//         anyhow::bail!("Invalid POINT WKT format: {}", wkt);
//     }
// }

// #[cfg(test)]
// mod tests {
//     use super::*;

//     #[test]
//     fn test_extract_point_coords() {
//         let wkt = "POINT(-122.4194 37.7749)";
//         let (lon, lat) = KmlProcessor::extract_point_coords(wkt).unwrap();
//         assert_eq!(lon, -122.4194);
//         assert_eq!(lat, 37.7749);
//     }

//     #[test]
//     fn test_first_coord() {
//         let coords = "-122.4194,37.7749,0 -118.2437,34.0522,0";
//         let (lon, lat) = KmlProcessor::first_coord(coords).unwrap();
//         assert_eq!(lon, -122.4194);
//         assert_eq!(lat, 37.7749);
//     }

//     #[test]
//     fn test_coordinate_parsing() {
//         let coord_string = "-122.4194,37.7749,0";
//         let parts: Vec<&str> = coord_string.split(',').collect();
//         assert_eq!(parts.len(), 3);
//         assert_eq!(parts[0], "-122.4194");
//         assert_eq!(parts[1], "37.7749");
        
//         let lon: f64 = parts[0].parse().unwrap();
//         let lat: f64 = parts[1].parse().unwrap();
//         assert_eq!(lon, -122.4194);
//         assert_eq!(lat, 37.7749);
//     }
// }
