use crate::kml::processor::extract_geometries_from_zip;
use crate::spatial_db::{
    AnalyticsResult, DatabaseInfo, KmlRecord, LinkRecord, PathResult, SiteRecord, SpatialDatabase,
};
use anyhow::Result as AnyhowResult;
use csv::ReaderBuilder;
use log::{debug, error, info, warn};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::fs::{self, File};
use std::path::Path;
use std::sync::{Arc, Mutex};
use tauri::{AppHandle, Emitter, Manager, State};

/// Type alias for the shared database manager
pub type DatabaseManager = Arc<Mutex<HashMap<String, SpatialDatabase>>>;

/// Request structure for creating a new database
#[derive(Debug, Serialize, Deserialize)]
pub struct CreateDatabaseRequest {
    pub name: String,
    pub description: Option<String>,
}

/// Request structure for importing data with structured records
#[derive(Debug, Serialize, Deserialize)]
pub struct ImportDataRequest {
    pub database_name: String,
    pub sites: Vec<SiteRecord>,
    pub links: Vec<LinkRecord>,
    pub kmz_base64: Option<String>,
}

/// Request structure for importing data from file paths
#[derive(Debug, Serialize, Deserialize)]
pub struct ImportFromFilesRequest {
    pub database_name: String,
    pub sites_csv_path: Option<String>,
    pub links_csv_path: Option<String>,
    pub kml_zip_path: Option<String>,
}

/// Progress update payload for async operations
#[derive(Debug, Serialize, Clone)]
struct ProgressPayload {
    stage: String,
    processed: usize,
    total: usize,
    message: Option<String>,
}

// ============================================================================
// Database Lifecycle Management
// ============================================================================

/// Creates a new spatial database with the given name
#[tauri::command]
pub fn create_database(
    request: CreateDatabaseRequest,
    app_handle: AppHandle,
    databases: State<'_, DatabaseManager>,
) -> Result<DatabaseInfo, String> {
    info!("🗃️ Creating database: {}", request.name);

    let app_data_dir = app_handle
        .path()
        .app_data_dir()
        .map_err(|e| {
            error!("Failed to get app data directory: {}", e);
            format!("Failed to get app data directory: {}", e)
        })?;

    std::fs::create_dir_all(&app_data_dir).map_err(|e| {
        error!("Failed to create app data directory: {}", e);
        format!("Failed to create app data directory: {}", e)
    })?;

    let db_path = app_data_dir.join(format!("{}.sqlite", request.name));
    debug!("Creating database at path: {:?}", db_path);

    if db_path.exists() {
        warn!("Database {} already exists, will overwrite", request.name);
    }

    let db = SpatialDatabase::new(&db_path, request.name.clone(), Some(&app_handle))
        .map_err(|e| {
            error!("Failed to create database {}: {}", request.name, e);
            format!("Failed to create database: {}", e)
        })?;

    let info = db.get_database_info();

    let mut manager = databases.lock().map_err(|e| {
        error!("Failed to acquire database manager lock: {}", e);
        "Failed to acquire database lock".to_string()
    })?;
    
    manager.insert(request.name.clone(), db);

    info!("✅ Database {} created successfully", request.name);
    Ok(info)
}

/// Deletes a database both from memory and disk
#[tauri::command]
pub fn delete_database(
    db_name: String,
    app_handle: AppHandle,
    databases: State<'_, DatabaseManager>,
) -> Result<String, String> {
    info!("🗑️ Deleting database: {}", db_name);

    // Remove from memory
    {
        let mut manager = databases.lock().map_err(|e| {
            error!("Failed to acquire database manager lock: {}", e);
            "Failed to acquire database lock".to_string()
        })?;
        manager.remove(&db_name);
    }

    // Delete file from filesystem
    let app_data_dir = app_handle
        .path()
        .app_data_dir()
        .map_err(|e| {
            error!("Failed to get app data directory: {}", e);
            format!("Failed to get app data directory: {}", e)
        })?;

    let db_path = app_data_dir.join(format!("{}.sqlite", db_name));

    if db_path.exists() {
        std::fs::remove_file(&db_path).map_err(|e| {
            error!("Failed to delete database file {:?}: {}", db_path, e);
            format!("Failed to delete database file: {}", e)
        })?;
        info!("✅ Database file deleted: {:?}", db_path);
    } else {
        warn!("Database file not found: {:?}", db_path);
    }

    let message = format!("Database '{}' deleted successfully", db_name);
    info!("{}", message);
    Ok(message)
}

/// Loads an existing database from disk into memory
#[tauri::command]
pub fn load_database(
    db_name: String,
    app_handle: AppHandle,
    databases: State<'_, DatabaseManager>,
) -> Result<DatabaseInfo, String> {
    info!("🔄 Loading database: {}", db_name);

    let app_data_dir = app_handle
        .path()
        .app_data_dir()
        .map_err(|e| format!("Failed to get app data directory: {}", e))?;

    let db_path = app_data_dir.join(format!("{}.sqlite", db_name));

    if !db_path.exists() {
        let error = format!("Database file not found: {}", db_name);
        error!("{}", error);
        return Err(error);
    }

    let db = SpatialDatabase::new(&db_path, db_name.clone(), Some(&app_handle))
        .map_err(|e| {
            error!("Failed to load database {}: {}", db_name, e);
            format!("Failed to load database: {}", e)
        })?;

    let info = db.get_database_info();

    let mut manager = databases.lock().map_err(|e| {
        error!("Failed to acquire database manager lock: {}", e);
        "Failed to acquire database lock".to_string()
    })?;

    manager.insert(db_name.clone(), db);

    info!("✅ Database {} loaded successfully", db_name);
    Ok(info)
}

#[tauri::command]
pub fn get_database_info(
    db_name: String,
    app_handle: AppHandle,
    databases: State<'_, DatabaseManager>,
) -> Result<DatabaseInfo, String> {
    debug!("ℹ️ Getting database info for: {}", db_name);

    ensure_database_loaded(&db_name, &app_handle, &databases)?;

    let manager = databases.lock().map_err(|e| {
        error!("Failed to acquire database manager lock: {}", e);
        "Failed to acquire database lock".to_string()
    })?;

    let db = manager
        .get(&db_name)
        .ok_or_else(|| format!("Database '{}' not found", db_name))?;

    // Get basic info from database
    let mut info = db.get_database_info();
    
    // Calculate actual file size
    let app_data_dir = app_handle
        .path()
        .app_data_dir()
        .map_err(|e| {
            error!("Failed to get app data directory: {}", e);
            format!("Failed to get app data directory: {}", e)
        })?;

    let db_path = app_data_dir.join(format!("{}.sqlite", db_name));
    
    // Get file size if it exists on disk
    if db_path.exists() {
        match std::fs::metadata(&db_path) {
            Ok(metadata) => {
                info.size_bytes = metadata.len();
                debug!("Database {} file size: {} bytes", db_name, info.size_bytes);
            }
            Err(e) => {
                warn!("Failed to get file metadata for {}: {}", db_name, e);
                // Keep size_bytes as 0 for in-memory databases or if metadata fails
            }
        }
    } else {
        debug!("Database {} appears to be in-memory (no file found)", db_name);
        // Keep size_bytes as 0 for in-memory databases
    }

    debug!(
        "Database {} info: {} sites, {} links, {} bytes",
        db_name, info.site_count, info.link_count, info.size_bytes
    );
    
    Ok(info)
}

/// Lists all available databases with their file sizes
#[tauri::command]
pub fn list_databases(
    app_handle: AppHandle,
    databases: State<'_, DatabaseManager>,
) -> Result<Vec<DatabaseInfo>, String> {
    debug!("📋 Listing all databases with details");

    let app_data_dir = app_handle
        .path()
        .app_data_dir()
        .map_err(|e| {
            error!("Failed to get app data directory: {}", e);
            format!("Failed to get app data directory: {}", e)
        })?;

    let mut db_list = Vec::new();

    // Scan filesystem for .sqlite files
    if app_data_dir.exists() {
        let entries = fs::read_dir(&app_data_dir).map_err(|e| {
            error!("Failed to read app data directory: {}", e);
            format!("Failed to read app data directory: {}", e)
        })?;

        for entry in entries {
            if let Ok(entry) = entry {
                let path = entry.path();
                if path.is_file() && path.extension().and_then(|s| s.to_str()) == Some("sqlite") {
                    if let Some(name) = path.file_stem().and_then(|s| s.to_str()) {
                        debug!("Found database file: {}", name);
                        
                        // Get file size
                        let size_bytes = match std::fs::metadata(&path) {
                            Ok(metadata) => metadata.len(),
                            Err(e) => {
                                warn!("Failed to get metadata for {}: {}", name, e);
                                0
                            }
                        };

                        // Check if database is loaded in memory to get accurate counts
                        let manager = databases.lock().map_err(|e| {
                            error!("Failed to acquire database manager lock: {}", e);
                            "Failed to acquire database lock".to_string()
                        })?;

                        let (site_count, link_count) = if let Some(db) = manager.get(name) {
                            let info = db.get_database_info();
                            (info.site_count, info.link_count)
                        } else {
                            // Database not loaded, we can't get counts without loading it
                            // For performance, we'll show 0 and let user load it if they want details
                            (0, 0)
                        };

                        drop(manager); // Release lock

                        let db_info = DatabaseInfo {
                            name: name.to_string(),
                            site_count,
                            link_count,
                            created_at: chrono::Utc::now().to_rfc3339(), // We could get this from file metadata too
                            size_bytes,
                        };

                        db_list.push(db_info);
                    }
                }
            }
        }
    }

    // Add any in-memory databases that aren't on disk
    let manager = databases.lock().map_err(|e| {
        error!("Failed to acquire database manager lock: {}", e);
        "Failed to acquire database lock".to_string()
    })?;

    for (name, db) in manager.iter() {
        // Check if this database is already in our list (from file scan)
        if !db_list.iter().any(|info| &info.name == name) {
            let info = db.get_database_info();
            db_list.push(DatabaseInfo {
                name: name.clone(),
                site_count: info.site_count,
                link_count: info.link_count,
                created_at: info.created_at,
                size_bytes: 0, // In-memory databases have no file size
            });
        }
    }

    // Sort by name for consistent ordering
    db_list.sort_by(|a, b| a.name.cmp(&b.name));

    info!("📊 Found {} databases", db_list.len());
    for db in &db_list {
        debug!(
            "  - {}: {} sites, {} links, {} bytes",
            db.name, db.site_count, db.link_count, db.size_bytes
        );
    }

    Ok(db_list)
}

// ============================================================================
// Data Import Operations
// ============================================================================

/// Imports structured data (sites and links) into a database
#[tauri::command]
pub fn import_data(
    request: ImportDataRequest,
    app_handle: AppHandle,
    databases: State<'_, DatabaseManager>,
) -> Result<String, String> {
    info!("📥 Importing data to database: {}", request.database_name);

    ensure_database_loaded(&request.database_name, &app_handle, &databases)?;

    let manager = databases.lock().map_err(|e| {
        error!("Failed to acquire database manager lock: {}", e);
        "Failed to acquire database lock".to_string()
    })?;

    let db = manager
        .get(&request.database_name)
        .ok_or_else(|| format!("Database '{}' not found", request.database_name))?;

    let mut sites_imported = 0;
    let mut links_imported = 0;

    // Import sites
    for site in &request.sites {
        match db.insert_site(site) {
            Ok(_) => {
                sites_imported += 1;
                if sites_imported % 1000 == 0 {
                    debug!("Imported {} sites so far...", sites_imported);
                }
            }
            Err(e) => {
                error!("Failed to insert site {}: {}", site.site_id, e);
                return Err(format!("Failed to insert site {}: {}", site.site_id, e));
            }
        }
    }

    // Import links
    for link in &request.links {
        match db.insert_link(link) {
            Ok(_) => {
                links_imported += 1;
                if links_imported % 1000 == 0 {
                    debug!("Imported {} links so far...", links_imported);
                }
            }
            Err(e) => {
                error!("Failed to insert link {}: {}", link.link_id, e);
                return Err(format!("Failed to insert link {}: {}", link.link_id, e));
            }
        }
    }

    // Handle KMZ import if provided
    let mut geometries_applied = 0;
    if let Some(kmz_data) = &request.kmz_base64 {
        info!("🗺️ Processing KMZ data...");

        match extract_geometries_from_zip(kmz_data) {
            Ok(geometries) => {
                info!("Extracted {} geometries from KMZ", geometries.len());
                geometries_applied = geometries.len();
                // Note: Geometry application logic would go here
            }
            Err(e) => {
                error!("Failed to process KMZ data: {}", e);
                return Err(format!("Failed to process KMZ data: {}", e));
            }
        }
    }

    let message = if geometries_applied > 0 {
        format!(
            "Imported {} sites, {} links, and applied {} geometries",
            sites_imported, links_imported, geometries_applied
        )
    } else {
        format!(
            "Imported {} sites and {} links",
            sites_imported, links_imported
        )
    };

    info!("✅ {}", message);
    Ok(message)
}

/// Imports data from CSV and KML files with progress reporting
#[tauri::command]
pub async fn import_from_files(
    request: ImportFromFilesRequest,
    app_handle: AppHandle,
    databases: State<'_, DatabaseManager>,
) -> Result<String, String> {
    info!("📦 Processing file import for database: {}", request.database_name);

    // Ensure database is loaded
    ensure_database_loaded(&request.database_name, &app_handle, &databases)?;

    // Clone necessary data for the blocking task
    let db_state = Arc::clone(databases.inner());
    let handle_clone = app_handle.clone();

    // Run the blocking I/O operations in a separate thread
    tokio::task::spawn_blocking(move || {
        import_from_files_blocking(request, handle_clone, db_state)
    })
    .await
    .map_err(|e| format!("Task execution failed: {}", e))?
}

/// Internal blocking implementation of file import
fn import_from_files_blocking(
    request: ImportFromFilesRequest,
    app_handle: AppHandle,
    databases: DatabaseManager,
) -> Result<String, String> {
    let manager = databases.lock().map_err(|e| {
        error!("Failed to acquire database manager lock: {}", e);
        "Failed to acquire database lock".to_string()
    })?;

    let db = manager
        .get(&request.database_name)
        .ok_or_else(|| format!("Database '{}' not found", request.database_name))?;

    let mut sites_imported = 0;
    let mut links_imported = 0;
    let mut geometries_imported = 0;

    // Import Sites CSV
    if let Some(ref sites_csv_path) = request.sites_csv_path {
        info!("🏢 Processing sites CSV file: {}", sites_csv_path);
        
        if !Path::new(sites_csv_path).exists() {
            return Err(format!("Sites CSV file not found: {}", sites_csv_path));
        }

        let sites = parse_sites_csv_from_file(sites_csv_path)
            .map_err(|e| format!("Failed to parse sites CSV: {}", e))?;

        let total = sites.len();
        for (i, site) in sites.iter().enumerate() {
            if db.insert_site(site).is_ok() {
                sites_imported += 1;
            }

            // Send progress updates
            if (i + 1) % 500 == 0 || i + 1 == total {
                let _ = app_handle.emit(
                    "import-progress",
                    ProgressPayload {
                        stage: "sites".to_string(),
                        processed: i + 1,
                        total,
                        message: Some(format!("Imported {} of {} sites", i + 1, total)),
                    },
                );
            }
        }
        info!("✅ Imported {} sites", sites_imported);
    }

    // Import Links CSV
    if let Some(ref links_csv_path) = request.links_csv_path {
        info!("🔗 Processing links CSV file: {}", links_csv_path);
        
        if !Path::new(links_csv_path).exists() {
            return Err(format!("Links CSV file not found: {}", links_csv_path));
        }

        let links = parse_links_csv_from_file(links_csv_path)
            .map_err(|e| format!("Failed to parse links CSV: {}", e))?;

        let total = links.len();
        for (i, link) in links.iter().enumerate() {
            if db.insert_link(link).is_ok() {
                links_imported += 1;
            }

            // Send progress updates
            if (i + 1) % 500 == 0 || i + 1 == total {
                let _ = app_handle.emit(
                    "import-progress",
                    ProgressPayload {
                        stage: "links".to_string(),
                        processed: i + 1,
                        total,
                        message: Some(format!("Imported {} of {} links", i + 1, total)),
                    },
                );
            }
        }
        info!("✅ Imported {} links", links_imported);
    }

    // Import KML ZIP
    if let Some(ref kml_zip_path) = request.kml_zip_path {
        info!("🗺️ Processing KML ZIP file: {}", kml_zip_path);
        
        if !Path::new(kml_zip_path).exists() {
            return Err(format!("KML ZIP file not found: {}", kml_zip_path));
        }

        let zip_data = fs::read(kml_zip_path)
            .map_err(|e| format!("Failed to read KML ZIP file: {}", e))?;
        
        let base64_data = base64::encode(&zip_data);

        match extract_geometries_from_zip(&base64_data) {
            Ok(geometries) => {
                info!("📍 Extracted {} geometries from KML ZIP", geometries.len());

                let kml_records: Vec<KmlRecord> = geometries
                    .into_iter()
                    .map(|g| KmlRecord {
                        lib_no: g.lib_no,
                        geometry_type: g.geometry_type,
                        wkt: g.wkt,
                    })
                    .collect();

                // Drop read lock and get mutable DB reference
                drop(manager);
                let mut manager = databases.lock().map_err(|e| {
                    error!("Failed to acquire database manager lock: {}", e);
                    "Failed to acquire database lock".to_string()
                })?;

                let db_mut = manager
                    .get_mut(&request.database_name)
                    .ok_or_else(|| format!("Database '{}' not found", request.database_name))?;

                let total = kml_records.len();
                for (i, chunk) in kml_records.chunks(500).enumerate() {
                    db_mut
                        .insert_kml_bulk(chunk)
                        .map_err(|e| format!("Failed to insert KML records: {}", e))?;
                    
                    geometries_imported += chunk.len();

                    let processed = ((i + 1) * 500).min(total);
                    let _ = app_handle.emit(
                        "import-progress",
                        ProgressPayload {
                            stage: "kml".to_string(),
                            processed,
                            total,
                            message: Some(format!("Imported {} of {} KML records", processed, total)),
                        },
                    );
                }
                info!("✅ Inserted {} KML records into database", geometries_imported);
            }
            Err(e) => {
                warn!("Failed to process KML ZIP: {}", e);
                return Err(format!("Failed to process KML ZIP: {}", e));
            }
        }
    }

    let message = format!(
        "Successfully imported {} sites, {} links, and {} KML geometries",
        sites_imported, links_imported, geometries_imported
    );
    
    info!("✅ {}", message);
    Ok(message)
}

// ============================================================================
// CRUD Operations
// ============================================================================

/// Retrieves all sites from the specified database
#[tauri::command]
pub fn get_all_sites(
    db_name: String,
    app_handle: AppHandle,
    databases: State<'_, DatabaseManager>,
) -> Result<Vec<SiteRecord>, String> {
    debug!("📍 Getting all sites from database: {}", db_name);

    ensure_database_loaded(&db_name, &app_handle, &databases)?;

    let manager = databases.lock().map_err(|e| {
        error!("Failed to acquire database manager lock: {}", e);
        "Failed to acquire database lock".to_string()
    })?;

    let db = manager
        .get(&db_name)
        .ok_or_else(|| format!("Database '{}' not found", db_name))?;

    let sites = db.get_all_sites().map_err(|e| {
        error!("Failed to get sites from {}: {}", db_name, e);
        format!("Failed to get sites: {}", e)
    })?;

    debug!("Retrieved {} sites from {}", sites.len(), db_name);
    Ok(sites)
}

/// Retrieves all links from the specified database
#[tauri::command]
pub fn get_all_links(
    db_name: String,
    app_handle: AppHandle,
    databases: State<'_, DatabaseManager>,
) -> Result<Vec<LinkRecord>, String> {
    debug!("🔗 Getting all links from database: {}", db_name);

    ensure_database_loaded(&db_name, &app_handle, &databases)?;

    let manager = databases.lock().map_err(|e| {
        error!("Failed to acquire database manager lock: {}", e);
        "Failed to acquire database lock".to_string()
    })?;

    let db = manager
        .get(&db_name)
        .ok_or_else(|| format!("Database '{}' not found", db_name))?;

    let links = db.get_all_links().map_err(|e| {
        error!("Failed to get links from {}: {}", db_name, e);
        format!("Failed to get links: {}", e)
    })?;

    debug!("Retrieved {} links from {}", links.len(), db_name);
    Ok(links)
}

/// Updates or inserts a site record
#[tauri::command]
pub fn update_site(
    db_name: String,
    site: SiteRecord,
    app_handle: AppHandle,
    databases: State<'_, DatabaseManager>,
) -> Result<String, String> {
    info!("✏️ Updating site {} in database {}", site.site_id, db_name);

    ensure_database_loaded(&db_name, &app_handle, &databases)?;

    let manager = databases.lock().map_err(|e| {
        error!("Failed to acquire database manager lock: {}", e);
        "Failed to acquire database lock".to_string()
    })?;

    let db = manager
        .get(&db_name)
        .ok_or_else(|| format!("Database '{}' not found", db_name))?;

    db.insert_site(&site).map_err(|e| {
        error!(
            "Failed to update site {} in {}: {}",
            site.site_id, db_name, e
        );
        format!("Failed to update site: {}", e)
    })?;

    let message = format!("Site {} updated successfully", site.site_id);
    info!("✅ {}", message);
    Ok(message)
}

/// Updates or inserts a link record
#[tauri::command]
pub fn update_link(
    db_name: String,
    link: LinkRecord,
    app_handle: AppHandle,
    databases: State<'_, DatabaseManager>,
) -> Result<String, String> {
    info!("✏️ Updating link {} in database {}", link.link_id, db_name);

    ensure_database_loaded(&db_name, &app_handle, &databases)?;

    let manager = databases.lock().map_err(|e| {
        error!("Failed to acquire database manager lock: {}", e);
        "Failed to acquire database lock".to_string()
    })?;

    let db = manager
        .get(&db_name)
        .ok_or_else(|| format!("Database '{}' not found", db_name))?;

    db.insert_link(&link).map_err(|e| {
        error!(
            "Failed to update link {} in {}: {}",
            link.link_id, db_name, e
        );
        format!("Failed to update link: {}", e)
    })?;

    let message = format!("Link {} updated successfully", link.link_id);
    info!("✅ {}", message);
    Ok(message)
}

// ============================================================================
// Analytics and Pathfinding
// ============================================================================

/// Gets analytics data for the specified database
#[tauri::command]
pub fn get_analytics(
    db_name: String,
    app_handle: AppHandle,
    databases: State<'_, DatabaseManager>,
) -> Result<AnalyticsResult, String> {
    info!("📊 Getting analytics from database: {}", db_name);

    ensure_database_loaded(&db_name, &app_handle, &databases)?;

    let manager = databases.lock().map_err(|e| {
        error!("Failed to acquire database manager lock: {}", e);
        "Failed to acquire database lock".to_string()
    })?;

    let db = manager
        .get(&db_name)
        .ok_or_else(|| format!("Database '{}' not found", db_name))?;

    let analytics = db.get_analytics().map_err(|e| {
        error!("Failed to get analytics from {}: {}", db_name, e);
        format!("Failed to get analytics: {}", e)
    })?;

    info!("✅ Retrieved analytics from {}", db_name);
    Ok(analytics)
}

/// Finds the shortest path between two sites
#[tauri::command]
pub fn find_shortest_path(
    db_name: String,
    source: String,
    destination: String,
    app_handle: AppHandle,
    databases: State<'_, DatabaseManager>,
) -> Result<PathResult, String> {
    info!(
        "🔍 Finding path from {} to {} in database {}",
        source, destination, db_name
    );

    ensure_database_loaded(&db_name, &app_handle, &databases)?;

    let manager = databases.lock().map_err(|e| {
        error!("Failed to acquire database manager lock: {}", e);
        "Failed to acquire database lock".to_string()
    })?;

    let db = manager
        .get(&db_name)
        .ok_or_else(|| format!("Database '{}' not found", db_name))?;

    let path = db.find_shortest_path(&source, &destination).map_err(|e| {
        error!(
            "Failed to find path from {} to {} in {}: {}",
            source, destination, db_name, e
        );
        format!("Failed to find path: {}", e)
    })?;

    info!(
        "✅ Found path with {} hops from {} to {}",
        path.hop_count, source, destination
    );
    Ok(path)
}

// ============================================================================
// PBF Tile Generation for Mapping
// ============================================================================

/// Generates PBF tile data for sites
#[tauri::command]
pub fn get_sites_pbf(
    db_name: String,
    z: u32,
    x: u32,
    y: u32,
    app_handle: AppHandle,
    databases: State<'_, DatabaseManager>,
) -> Result<Vec<u8>, String> {
    debug!(
        "🗺️ Generating sites PBF tile {}/{}/{} for database {}",
        z, x, y, db_name
    );

    ensure_database_loaded(&db_name, &app_handle, &databases)?;

    let manager = databases.lock().map_err(|e| {
        error!("Failed to acquire database manager lock: {}", e);
        "Failed to acquire database lock".to_string()
    })?;

    let db = manager
        .get(&db_name)
        .ok_or_else(|| format!("Database '{}' not found", db_name))?;

    let pbf_data = db.get_sites_pbf_tile(z, x, y).map_err(|e| {
        error!(
            "Failed to generate sites PBF tile {}/{}/{} for {}: {}",
            z, x, y, db_name, e
        );
        format!("Failed to generate PBF tile: {}", e)
    })?;

    debug!(
        "Generated sites PBF tile {}/{}/{} ({} bytes)",
        z,
        x,
        y,
        pbf_data.len()
    );
    Ok(pbf_data)
}

/// Generates PBF tile data for links
#[tauri::command]
pub fn get_links_pbf(
    db_name: String,
    z: u32,
    x: u32,
    y: u32,
    app_handle: AppHandle,
    databases: State<'_, DatabaseManager>,
) -> Result<Vec<u8>, String> {
    debug!(
        "🗺️ Generating links PBF tile {}/{}/{} for database {}",
        z, x, y, db_name
    );

    ensure_database_loaded(&db_name, &app_handle, &databases)?;

    let manager = databases.lock().map_err(|e| {
        error!("Failed to acquire database manager lock: {}", e);
        "Failed to acquire database lock".to_string()
    })?;

    let db = manager
        .get(&db_name)
        .ok_or_else(|| format!("Database '{}' not found", db_name))?;

    let pbf_data = db.get_links_pbf_tile(z, x, y).map_err(|e| {
        error!(
            "Failed to generate links PBF tile {}/{}/{} for {}: {}",
            z, x, y, db_name, e
        );
        format!("Failed to generate PBF tile: {}", e)
    })?;

    debug!(
        "Generated links PBF tile {}/{}/{} ({} bytes)",
        z,
        x,
        y,
        pbf_data.len()
    );
    Ok(pbf_data)
}

// ============================================================================
// Helper Functions
// ============================================================================

/// Ensures a database is loaded into memory, loading it if necessary
fn ensure_database_loaded(
    db_name: &str,
    app_handle: &AppHandle,
    databases: &State<'_, DatabaseManager>,
) -> Result<(), String> {
    let manager = databases.lock().map_err(|e| {
        error!("Failed to acquire database manager lock: {}", e);
        "Failed to acquire database lock".to_string()
    })?;

    if !manager.contains_key(db_name) {
        drop(manager);
        load_database(db_name.to_string(), app_handle.clone(), databases.clone())?;
    }

    Ok(())
}

/// Parses sites from a CSV file
fn parse_sites_csv_from_file(file_path: &str) -> AnyhowResult<Vec<SiteRecord>> {
    info!("📊 Parsing sites CSV from file: {}", file_path);

    let file = File::open(file_path)?;
    debug!("📁 File opened successfully");

    let mut reader = ReaderBuilder::new().has_headers(true).from_reader(file);
    let headers = reader.headers()?;
    debug!("Headers: {:?}", headers);

    let mut sites = Vec::new();
    let mut error_count = 0;

    for (i, result) in reader.deserialize::<SiteRecord>().enumerate() {
        match result {
            Ok(site) => {
                sites.push(site);
            }
            Err(e) => {
                error_count += 1;
                if error_count <= 10 {  // Only log first 10 errors to avoid spam
                    warn!("⚠️ Line {}: Failed to parse site record: {}", i + 2, e);
                }
            }
        }
    }

    if error_count > 10 {
        warn!("⚠️ {} additional parsing errors were suppressed", error_count - 10);
    }

    info!("✅ Parsed {} valid site records from {} total lines", 
          sites.len(), sites.len() + error_count);
    Ok(sites)
}

/// Parses links from a CSV file
fn parse_links_csv_from_file(file_path: &str) -> AnyhowResult<Vec<LinkRecord>> {
    info!("📊 Parsing links CSV from file: {}", file_path);

    let file = File::open(file_path)?;
    let mut reader = ReaderBuilder::new().has_headers(true).from_reader(file);

    let mut links = Vec::new();
    let mut error_count = 0;

    for (i, result) in reader.deserialize::<LinkRecord>().enumerate() {
        match result {
            Ok(link) => {
                links.push(link);
            }
            Err(e) => {
                error_count += 1;
                if error_count <= 10 {  // Only log first 10 errors to avoid spam
                    warn!("⚠️ Line {}: Failed to parse link record: {}", i + 2, e);
                }
            }
        }
    }

    if error_count > 10 {
        warn!("⚠️ {} additional parsing errors were suppressed", error_count - 10);
    }

    info!("✅ Parsed {} valid link records from {} total lines", 
          links.len(), links.len() + error_count);
    Ok(links)
}