// src-tauri/src/spatial_db.rs
use anyhow::{Context, Result};
use log::{debug, error, info, warn};
use rusqlite::{params, Connection, LoadExtensionGuard, Result as SqliteResult};
use serde::{Deserialize, Deserializer, Serialize};
use std::path::{Path, PathBuf};
use tauri::{path::BaseDirectory, AppHandle, Manager};
pub fn from_yn<'de, D>(deserializer: D) -> Result<bool, D::Error>
where
    D: Deserializer<'de>,
{
    let s: String = Deserialize::deserialize(deserializer)?;
    Ok(matches!(
        s.trim().to_uppercase().as_str(),
        "Y" | "YES" | "TRUE"
    ))
}
#[derive(Debug, Deserialize, Clone, Serialize)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub struct SiteRecord {
    pub site_id: String,
    pub site_vname: Option<String>,
    pub site_sname: Option<String>,
    pub site_lname: Option<String>,

    #[serde(deserialize_with = "from_yn")]
    pub is_metro: bool,

    #[serde(deserialize_with = "from_yn")]
    pub is_ldn: bool,

    #[serde(deserialize_with = "from_yn")]
    pub is_active: bool,

    pub city: Option<String>,

    #[serde(deserialize_with = "from_yn")]
    pub is_exitpoint: bool,
    // Make this optional in case the field is sometimes blank
    pub no_of_neighbour: Option<i32>,

    pub building_id: Option<String>,
    pub xng_site_name: Option<String>,
    pub site_owner: Option<String>,
    pub created_on: Option<String>,
    pub created_by: Option<String>,

    #[serde(deserialize_with = "from_yn")]
    pub is_visible: bool,

    pub zone: Option<String>,

    #[serde(deserialize_with = "from_yn")]
    pub is_zonal_exit: bool,

    pub zonal_neighbour: Option<String>,
    pub kmz_lib_no: Option<String>,
    pub country: Option<String>,

    #[serde(deserialize_with = "from_yn")]
    pub is_capacity_allow: bool,

    pub err_code: Option<String>,
    pub room: Option<String>,
    pub floor: Option<String>,

    #[serde(deserialize_with = "from_yn")]
    pub is_10g_site: bool,

    #[serde(deserialize_with = "from_yn")]
    pub is_bypass_site: bool,

    pub tid_id: Option<String>,
    pub arch_type: Option<String>,
    pub platform: Option<String>,
    pub network: Option<String>,

    // These were not in the sample CSV but kept for extensibility
    pub geometry_wkt: Option<String>,
    pub latitude: Option<f64>,
    pub longitude: Option<f64>,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub struct LinkRecord {
    pub link_id: String,
    pub site_a: String,
    pub site_b: String,
    pub city: Option<String>,
    pub distance: f64,

    pub platency_t_100: Option<f64>,

    #[serde(deserialize_with = "from_yn")]
    pub is_active: bool,

    #[serde(deserialize_with = "from_yn")]
    pub is_ldn: bool,

    #[serde(deserialize_with = "from_yn")]
    pub is_metro: bool,

    #[serde(deserialize_with = "from_yn")]
    pub is_common_wire: bool,

    pub wire_code: Option<String>,
    pub xng_wms_id: Option<String>,
    pub kmz_lib_no: Option<String>,
    pub fiber_owner: Option<String>,

    #[serde(deserialize_with = "from_yn")]
    pub is_virtual: bool,

    pub created_on: Option<String>,
    pub created_by: Option<String>,
    pub zone: Option<String>,

    #[serde(deserialize_with = "from_yn")]
    pub is_subsea_link: bool,

    pub zonea: Option<String>,
    pub zoneb: Option<String>,
    pub link_name: Option<String>,
    pub country: Option<String>,
    pub countrya: Option<String>,
    pub countryb: Option<String>,
    pub m_latency: Option<f64>,
    pub err_code: Option<String>,

    #[serde(deserialize_with = "from_yn")]
    pub is_visible: bool,

    pub link_type: Option<String>,

    #[serde(deserialize_with = "from_yn")]
    pub is_capacityavailable: bool,

    pub fao: Option<String>,
    pub physical_path: Option<String>,
    pub platform: Option<String>,
    pub network: Option<String>,
    pub interconnect_links: Option<String>,
    pub geometry_wkt: Option<String>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct DatabaseInfo {
    pub name: String,
    pub site_count: i64,
    pub link_count: i64,
    pub created_at: String,
    pub size_bytes: u64,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub struct KmlRecord {
    pub lib_no: String,
    pub geometry_type: String,
    pub wkt: String, // WKT representation of the geometry
}

#[derive(Debug, Serialize, Deserialize)]
pub struct PathResult {
    pub path: Vec<String>,
    pub total_distance: f64,
    pub total_latency: f64,
    pub hop_count: i32,
    pub sites: Vec<SiteRecord>,
    pub links: Vec<LinkRecord>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct AnalyticsResult {
    pub total_sites: i64,
    pub total_links: i64,
    pub countries: Vec<String>,
    pub cities: Vec<String>,
    pub platforms: Vec<String>,
    pub networks: Vec<String>,
    pub site_types: Vec<(String, i64)>,
    pub link_types: Vec<(String, i64)>,
    pub avg_distance: f64,
    pub max_distance: f64,
    pub min_distance: f64,
}

pub struct SpatialDatabase {
    connection: Connection,
    name: String,
}

impl SpatialDatabase {
    pub fn new<P: AsRef<Path>>(
        db_path: P,
        name: String,
        app_handle: Option<&AppHandle>,
    ) -> Result<Self> {
        info!("🗄️ Creating/opening database: {}", name);

        let path = db_path.as_ref();
        debug!("Database path: {:?}", path);

        let conn = Connection::open(&path).context("Failed to open database file")?;
        conn.execute_batch(
            "PRAGMA foreign_keys = ON;
            PRAGMA synchronous = NORMAL;
            PRAGMA cache_size = -64000;
            PRAGMA journal_mode = WAL;
            PRAGMA temp_store = MEMORY;",
        )?;

        info!("📚 Initializing SpatiaLite extension");
        if let Some(handle) = app_handle {
            Self::init_spatialite(&conn, Some(handle))?;
        } else {
            Self::init_spatialite(&conn, None)?;
        }

        info!("🏗️ Creating database schema");
        Self::create_schema(&conn)?;

        info!("✅ Database {} ready", name);
        Ok(Self {
            connection: conn,
            name,
        })
    }

    pub fn create_in_memory_with_name(
        name: String,
        app_handle: Option<&AppHandle>,
    ) -> Result<Self> {
        info!("💾 Creating in-memory database: {}", name);

        let conn = Connection::open_in_memory().context("Failed to open in-memory database")?;

        conn.execute_batch("PRAGMA foreign_keys = ON")?;

        if let Some(handle) = app_handle {
            Self::init_spatialite(&conn, Some(handle))?;
        } else {
            Self::init_spatialite(&conn, None)?;
        }

        Self::create_schema(&conn)?;
        info!("✅ In-memory database {} ready", name);
        Ok(Self {
            connection: conn,
            name,
        })
    }

    // Get public access to connection for PBF generation
    pub fn connection(&self) -> &Connection {
        &self.connection
    }

    fn get_spatialite_lib_path(app_handle: Option<&AppHandle>) -> Result<PathBuf> {
        if let Some(handle) = app_handle {
            let arch_dir = if cfg!(target_os = "macos") {
                if cfg!(target_arch = "aarch64") {
                    "libs/mac-arm64"
                } else {
                    "libs/mac-x64"
                }
            } else if cfg!(target_os = "windows") {
                "libs/win-x64"
            } else {
                "libs/linux-x64"
            };

            let candidates: &[&str] = if cfg!(target_os = "macos") {
                &["mod_spatialite.dylib", "libspatialite.dylib"]
            } else if cfg!(target_os = "windows") {
                &["mod_spatialite.dll", "spatialite.dll"]
            } else {
                &["mod_spatialite.so", "libspatialite.so"]
            };

            for &lib_name in candidates {
                let resource_path = format!("{}/{}", arch_dir, lib_name);
                if let Ok(resolved_path) = handle
                    .path()
                    .resolve(&resource_path, BaseDirectory::Resource)
                {
                    if resolved_path.exists() {
                        debug!("Found SpatiaLite library: {:?}", resolved_path);
                        return Ok(resolved_path);
                    }
                }
            }
        }

        // Fallback method
        use std::env;
        let base = if cfg!(debug_assertions) {
            PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("resources")
        } else {
            let exe = env::current_exe().context("failed to get current exe path")?;
            let exe_dir = exe.parent().context("exe has no parent dir")?;

            #[cfg(target_os = "macos")]
            {
                let contents = exe_dir.parent().context("missing Contents folder")?;
                contents.join("Resources")
            }

            #[cfg(not(target_os = "macos"))]
            {
                exe_dir.join("resources")
            }
        };

        let arch = if cfg!(target_os = "macos") {
            if cfg!(target_arch = "aarch64") {
                "mac-arm64"
            } else {
                "mac-x64"
            }
        } else if cfg!(target_os = "windows") {
            "win-x64"
        } else {
            "linux-x64"
        };

        let dir = base.join("libs").join(arch);
        let candidates: &[&str] = if cfg!(target_os = "macos") {
            &["mod_spatialite.dylib", "libspatialite.dylib"]
        } else if cfg!(target_os = "windows") {
            &["mod_spatialite.dll", "spatialite.dll"]
        } else {
            &["mod_spatialite.so", "libspatialite.so"]
        };

        for &name in candidates {
            let path = dir.join(name);
            if path.exists() {
                debug!("Found SpatiaLite library (fallback): {:?}", path);
                return Ok(path);
            }
        }

        error!("SpatiaLite library not found in any expected location");
        anyhow::bail!("SpatiaLite library not found")
    }

    fn init_spatialite(conn: &Connection, app_handle: Option<&AppHandle>) -> Result<()> {
        let _guard = unsafe { LoadExtensionGuard::new(conn)? };
        let lib_path = Self::get_spatialite_lib_path(app_handle)?;

        info!("📦 Loading SpatiaLite from: {:?}", lib_path);
        unsafe {
            conn.load_extension(&lib_path, None).with_context(|| {
                format!("Failed to load SpatiaLite extension from {:?}", lib_path)
            })?;
        }

        debug!("🌍 Initializing spatial metadata");
        conn.execute_batch("SELECT InitSpatialMetaData(1);")
            .context("Failed to run InitSpatialMetaData")?;

        info!("✅ SpatiaLite initialized successfully");
        Ok(())
    }

    fn create_schema(conn: &Connection) -> Result<()> {
        debug!("🏗️ Creating database schema...");

        // Helper function to ignore "already exists" errors
        fn execute_ddl_ignore_exists(conn: &Connection, sql: &str) -> Result<()> {
            match conn.execute_batch(sql) {
                Ok(_) => Ok(()),
                Err(e) => {
                    let error_str = e.to_string().to_lowercase();
                    if error_str.contains("already exists")
                        || error_str.contains("duplicate column name")
                        || error_str.contains("spatialindex is already defined")
                    {
                        debug!("Ignoring expected error: {}", e);
                        Ok(())
                    } else {
                        Err(e.into())
                    }
                }
            }
        }
        // Create base tables
        conn.execute_batch(
            r#"
        -- Sites table with complete schema
        CREATE TABLE IF NOT EXISTS sites (
            site_id TEXT PRIMARY KEY,
            site_vname TEXT,
            site_sname TEXT,
            site_lname TEXT,
            is_metro INTEGER DEFAULT 0,
            is_ldn INTEGER DEFAULT 0,
            is_active INTEGER DEFAULT 1,
            city TEXT,
            is_exitpoint INTEGER DEFAULT 0,
            no_of_neighbour INTEGER DEFAULT 0,
            building_id TEXT,
            xng_site_name TEXT,
            site_owner TEXT,
            created_on TEXT,
            created_by TEXT,
            is_visible INTEGER DEFAULT 1,
            zone TEXT,
            is_zonal_exit INTEGER DEFAULT 0,
            zonal_neighbour TEXT,
            kmz_lib_no TEXT,
            country TEXT,
            is_capacity_allow INTEGER DEFAULT 1,
            err_code TEXT,
            room TEXT,
            floor TEXT,
            is_10g_site INTEGER DEFAULT 0,
            is_bypass_site INTEGER DEFAULT 0,
            tid_id TEXT,
            arch_type TEXT,
            platform TEXT,
            network TEXT,
            latitude REAL,
            longitude REAL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );
        -- Links table with complete schema
        CREATE TABLE IF NOT EXISTS links (
            link_id TEXT PRIMARY KEY,
            site_a TEXT NOT NULL,
            site_b TEXT NOT NULL,
            city TEXT,
            distance REAL DEFAULT 0,
            platency_t_100 REAL,
            is_active INTEGER DEFAULT 1,
            is_ldn INTEGER DEFAULT 0,
            is_metro INTEGER DEFAULT 0,
            is_common_wire INTEGER DEFAULT 0,
            wire_code TEXT,
            xng_wms_id TEXT,
            kmz_lib_no TEXT,
            fiber_owner TEXT,
            is_virtual INTEGER DEFAULT 0,
            created_on TEXT,
            created_by TEXT,
            zone TEXT,
            is_subsea_link INTEGER DEFAULT 0,
            zonea TEXT,
            zoneb TEXT,
            link_name TEXT,
            country TEXT,
            countrya TEXT,
            countryb TEXT,
            m_latency REAL,
            err_code TEXT,
            is_visible INTEGER DEFAULT 1,
            link_type TEXT,
            is_capacityavailable INTEGER DEFAULT 1,
            fao TEXT,
            physical_path TEXT,
            platform TEXT,
            network TEXT,
            interconnect_links TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (site_a) REFERENCES sites(site_id) ON DELETE CASCADE,
            FOREIGN KEY (site_b) REFERENCES sites(site_id) ON DELETE CASCADE
        );
        "#,
        )
        .context("Failed to create base tables")?;

        conn.execute_batch(
            r#"
            CREATE TABLE IF NOT EXISTS kmls (
                lib_no TEXT NOT NULL,
                geometry_type TEXT NOT NULL
            );
            SELECT AddGeometryColumn('kmls', 'geom', 4326, 'GEOMETRY', 'XY');
            CREATE INDEX IF NOT EXISTS idx_kmls_lib_no ON kmls(lib_no);
            SELECT CreateSpatialIndex('kmls', 'geom');
            "#,
        )
        .context("Failed to create KML table")?;

        // Add geometry columns (ignore if already exist)
        debug!("🌍 Adding geometry columns...");
        execute_ddl_ignore_exists(
            conn,
            "SELECT AddGeometryColumn('sites', 'geom', 4326, 'POINT', 'XY');",
        )?;
        execute_ddl_ignore_exists(
            conn,
            "SELECT AddGeometryColumn('links', 'geom', 4326, 'LINESTRING', 'XY');",
        )?;

        // Create spatial indexes (ignore if already exist)
        execute_ddl_ignore_exists(conn, "SELECT CreateSpatialIndex('sites', 'geom');")?;
        execute_ddl_ignore_exists(conn, "SELECT CreateSpatialIndex('links', 'geom');")?;
        // Create regular indexes
        debug!("📇 Creating database indexes...");
        conn.execute_batch(
            r#"
        -- Create regular indexes for performance
        CREATE INDEX IF NOT EXISTS idx_sites_country ON sites(country);
        CREATE INDEX IF NOT EXISTS idx_sites_city ON sites(city);
        CREATE INDEX IF NOT EXISTS idx_sites_platform ON sites(platform);
        CREATE INDEX IF NOT EXISTS idx_sites_network ON sites(network);
        CREATE INDEX IF NOT EXISTS idx_sites_active ON sites(is_active);
        CREATE INDEX IF NOT EXISTS idx_sites_kmz_lib_no ON sites(kmz_lib_no);
        
        CREATE INDEX IF NOT EXISTS idx_links_site_a ON links(site_a);
        CREATE INDEX IF NOT EXISTS idx_links_site_b ON links(site_b);
        CREATE INDEX IF NOT EXISTS idx_links_country ON links(country);
        CREATE INDEX IF NOT EXISTS idx_links_platform ON links(platform);
        CREATE INDEX IF NOT EXISTS idx_links_network ON links(network);
        CREATE INDEX IF NOT EXISTS idx_links_active ON links(is_active);
        CREATE INDEX IF NOT EXISTS idx_links_kmz_lib_no ON links(kmz_lib_no);
        "#,
        )
        .context("Failed to create indexes")?;

        // Create triggers (ignore if already exist)
        debug!("⚡ Creating database triggers...");
        execute_ddl_ignore_exists(
            conn,
            r#"
        -- Triggers to update geometry automatically
        CREATE TRIGGER IF NOT EXISTS update_site_geometry
        AFTER INSERT ON sites
        WHEN NEW.latitude IS NOT NULL AND NEW.longitude IS NOT NULL
        BEGIN
            UPDATE sites
            SET geom = MakePoint(NEW.longitude, NEW.latitude, 4326)
            WHERE site_id = NEW.site_id;
        END;

        CREATE TRIGGER IF NOT EXISTS update_site_geometry_on_update
        AFTER UPDATE ON sites
        WHEN NEW.latitude IS NOT NULL AND NEW.longitude IS NOT NULL
        BEGIN
            UPDATE sites
            SET geom = MakePoint(NEW.longitude, NEW.latitude, 4326),
                updated_at = CURRENT_TIMESTAMP
            WHERE site_id = NEW.site_id;
        END;

        CREATE TRIGGER IF NOT EXISTS update_link_geometry
        AFTER INSERT ON links
        BEGIN
            UPDATE links
            SET geom = (
                SELECT MakeLine(
                    MakePoint(s1.longitude, s1.latitude, 4326),
                    MakePoint(s2.longitude, s2.latitude, 4326)
                )
                FROM sites s1, sites s2
                WHERE s1.site_id = NEW.site_a AND s2.site_id = NEW.site_b
                AND s1.latitude IS NOT NULL AND s1.longitude IS NOT NULL
                AND s2.latitude IS NOT NULL AND s2.longitude IS NOT NULL
            )
            WHERE link_id = NEW.link_id;
        END;

        CREATE TRIGGER IF NOT EXISTS update_link_timestamp
        AFTER UPDATE ON links
        BEGIN
            UPDATE links
            SET updated_at = CURRENT_TIMESTAMP
            WHERE link_id = NEW.link_id;
        END;
        "#,
        )?;

        info!("✅ Database schema created successfully");
        Ok(())
    }
    // PBF Tile Generation Methods
    pub fn get_sites_pbf_tile(&self, z: u32, x: u32, y: u32) -> Result<Vec<u8>> {
        debug!("🗺️ Generating sites PBF tile {}/{}/{}", z, x, y);

        // Calculate tile bounds
        let (min_lon, min_lat, max_lon, max_lat) = Self::tile_to_bbox(z, x, y);

        // Query sites within tile bounds
        let mut stmt = self.connection.prepare(
            "SELECT site_id, site_sname, city, country, platform, network, 
                    latitude, longitude, AsText(geom) as wkt
             FROM sites 
             WHERE is_active = 1 
             AND latitude BETWEEN ?1 AND ?2 
             AND longitude BETWEEN ?3 AND ?4
             LIMIT 10000", // Prevent too many features
        )?;

        let rows = stmt.query_map(params![min_lat, max_lat, min_lon, max_lon], |row| {
            Ok((
                row.get::<_, String>(0)?,         // site_id
                row.get::<_, Option<String>>(1)?, // site_sname
                row.get::<_, Option<String>>(2)?, // city
                row.get::<_, Option<String>>(3)?, // country
                row.get::<_, Option<String>>(4)?, // platform
                row.get::<_, Option<String>>(5)?, // network
                row.get::<_, Option<f64>>(6)?,    // latitude
                row.get::<_, Option<f64>>(7)?,    // longitude
                row.get::<_, Option<String>>(8)?, // wkt
            ))
        })?;

        // Convert to simplified GeoJSON for now
        // In production, you'd use a proper MVT library like `mvt` crate
        let mut features = Vec::new();
        for row in rows {
            if let Ok((site_id, name, city, country, platform, network, lat, lon, _wkt)) = row {
                if let (Some(lat), Some(lon)) = (lat, lon) {
                    let feature = serde_json::json!({
                        "type": "Feature",
                        "geometry": {
                            "type": "Point",
                            "coordinates": [lon, lat]
                        },
                        "properties": {
                            "id": site_id,
                            "name": name.unwrap_or_default(),
                            "city": city.unwrap_or_default(),
                            "country": country.unwrap_or_default(),
                            "platform": platform.unwrap_or_default(),
                            "network": network.unwrap_or_default()
                        }
                    });
                    features.push(feature);
                }
            }
        }

        let geojson = serde_json::json!({
            "type": "FeatureCollection",
            "features": features
        });

        // For now, return GeoJSON as bytes
        // In production, convert this to proper MVT format
        let json_string = serde_json::to_string(&geojson)?;
        Ok(json_string.into_bytes())
    }

    pub fn get_links_pbf_tile(&self, z: u32, x: u32, y: u32) -> Result<Vec<u8>> {
        debug!("🗺️ Generating links PBF tile {}/{}/{}", z, x, y);

        // Calculate tile bounds
        let (min_lon, min_lat, max_lon, max_lat) = Self::tile_to_bbox(z, x, y);

        // Query links within tile bounds (more complex spatial query needed)
        let mut stmt = self.connection.prepare(
            "SELECT l.link_id, l.site_a, l.site_b, l.distance, l.link_type, l.platform, l.network,
                    s1.latitude as lat1, s1.longitude as lon1,
                    s2.latitude as lat2, s2.longitude as lon2,
                    AsText(l.geom) as wkt
             FROM links l
             JOIN sites s1 ON l.site_a = s1.site_id
             JOIN sites s2 ON l.site_b = s2.site_id
             WHERE l.is_active = 1
             AND ((s1.latitude BETWEEN ?1 AND ?2 AND s1.longitude BETWEEN ?3 AND ?4)
                OR (s2.latitude BETWEEN ?1 AND ?2 AND s2.longitude BETWEEN ?3 AND ?4))
             LIMIT 5000", // Prevent too many features
        )?;

        let rows = stmt.query_map(params![min_lat, max_lat, min_lon, max_lon], |row| {
            Ok((
                row.get::<_, String>(0)?,          // link_id
                row.get::<_, String>(1)?,          // site_a
                row.get::<_, String>(2)?,          // site_b
                row.get::<_, f64>(3)?,             // distance
                row.get::<_, Option<String>>(4)?,  // link_type
                row.get::<_, Option<String>>(5)?,  // platform
                row.get::<_, Option<String>>(6)?,  // network
                row.get::<_, Option<f64>>(7)?,     // lat1
                row.get::<_, Option<f64>>(8)?,     // lon1
                row.get::<_, Option<f64>>(9)?,     // lat2
                row.get::<_, Option<f64>>(10)?,    // lon2
                row.get::<_, Option<String>>(11)?, // wkt
            ))
        })?;

        // Convert to simplified GeoJSON for now
        let mut features = Vec::new();
        for row in rows {
            if let Ok((
                link_id,
                site_a,
                site_b,
                distance,
                link_type,
                platform,
                network,
                lat1,
                lon1,
                lat2,
                lon2,
                _wkt,
            )) = row
            {
                if let (Some(lat1), Some(lon1), Some(lat2), Some(lon2)) = (lat1, lon1, lat2, lon2) {
                    let feature = serde_json::json!({
                        "type": "Feature",
                        "geometry": {
                            "type": "LineString",
                            "coordinates": [[lon1, lat1], [lon2, lat2]]
                        },
                        "properties": {
                            "id": link_id,
                            "site_a": site_a,
                            "site_b": site_b,
                            "distance": distance,
                            "link_type": link_type.unwrap_or_default(),
                            "platform": platform.unwrap_or_default(),
                            "network": network.unwrap_or_default()
                        }
                    });
                    features.push(feature);
                }
            }
        }

        let geojson = serde_json::json!({
            "type": "FeatureCollection",
            "features": features
        });

        // For now, return GeoJSON as bytes
        let json_string = serde_json::to_string(&geojson)?;
        Ok(json_string.into_bytes())
    }

    /// Convert tile coordinates to geographic bounding box
    fn tile_to_bbox(z: u32, x: u32, y: u32) -> (f64, f64, f64, f64) {
        let n = 2.0_f64.powi(z as i32);
        let lon_min = (x as f64) / n * 360.0 - 180.0;
        let lon_max = ((x + 1) as f64) / n * 360.0 - 180.0;

        let lat_rad_max = ((std::f64::consts::PI * (1.0 - 2.0 * (y as f64) / n)).sinh()).atan();
        let lat_rad_min =
            ((std::f64::consts::PI * (1.0 - 2.0 * ((y + 1) as f64) / n)).sinh()).atan();

        let lat_min = lat_rad_min * 180.0 / std::f64::consts::PI;
        let lat_max = lat_rad_max * 180.0 / std::f64::consts::PI;

        (lon_min, lat_min, lon_max, lat_max)
    }

    // Keep all your existing CRUD methods...
    // [All the insert_site, get_all_sites, insert_link, get_all_links, etc. methods remain the same]

    // CRUD Operations for Sites
    pub fn insert_site(&self, site: &SiteRecord) -> Result<()> {
        let mut stmt = self.connection.prepare(
            "INSERT OR REPLACE INTO sites (
                site_id, site_vname, site_sname, site_lname, is_metro, is_ldn, is_active,
                city, is_exitpoint, no_of_neighbour, building_id, xng_site_name, site_owner,
                created_on, created_by, is_visible, zone, is_zonal_exit, zonal_neighbour,
                kmz_lib_no, country, is_capacity_allow, err_code, room, floor, is_10g_site,
                is_bypass_site, tid_id, arch_type, platform, network, latitude, longitude
            ) VALUES (
                ?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11, ?12, ?13, ?14, ?15, ?16,
                ?17, ?18, ?19, ?20, ?21, ?22, ?23, ?24, ?25, ?26, ?27, ?28, ?29, ?30, ?31, ?32, ?33
            )",
        )?;

        stmt.execute(params![
            site.site_id,
            site.site_vname,
            site.site_sname,
            site.site_lname,
            site.is_metro,
            site.is_ldn,
            site.is_active,
            site.city,
            site.is_exitpoint,
            site.no_of_neighbour,
            site.building_id,
            site.xng_site_name,
            site.site_owner,
            site.created_on,
            site.created_by,
            site.is_visible,
            site.zone,
            site.is_zonal_exit,
            site.zonal_neighbour,
            site.kmz_lib_no,
            site.country,
            site.is_capacity_allow,
            site.err_code,
            site.room,
            site.floor,
            site.is_10g_site,
            site.is_bypass_site,
            site.tid_id,
            site.arch_type,
            site.platform,
            site.network,
            site.latitude,
            site.longitude,
        ])?;

        // Update geometry from WKT if provided
        if let Some(ref wkt) = site.geometry_wkt {
            self.connection.execute(
                "UPDATE sites SET geom = GeomFromText(?1, 4326) WHERE site_id = ?2",
                params![wkt, site.site_id],
            )?;
        }

        Ok(())
    }

    pub fn get_all_sites(&self) -> Result<Vec<SiteRecord>> {
        let mut stmt = self.connection.prepare(
            "SELECT site_id, site_vname, site_sname, site_lname, is_metro, is_ldn, is_active,
             city, is_exitpoint, no_of_neighbour, building_id, xng_site_name, site_owner,
             created_on, created_by, is_visible, zone, is_zonal_exit, zonal_neighbour,
             kmz_lib_no, country, is_capacity_allow, err_code, room, floor, is_10g_site,
             is_bypass_site, tid_id, arch_type, platform, network, latitude, longitude,
             AsText(geom) as geometry_wkt
             FROM sites ORDER BY site_id",
        )?;

        let rows = stmt.query_map([], |row| {
            Ok(SiteRecord {
                site_id: row.get(0)?,
                site_vname: row.get(1)?,
                site_sname: row.get(2)?,
                site_lname: row.get(3)?,
                is_metro: row.get::<_, i32>(4)? != 0,
                is_ldn: row.get::<_, i32>(5)? != 0,
                is_active: row.get::<_, i32>(6)? != 0,
                city: row.get(7)?,
                is_exitpoint: row.get::<_, i32>(8)? != 0,
                no_of_neighbour: row.get(9)?,
                building_id: row.get(10)?,
                xng_site_name: row.get(11)?,
                site_owner: row.get(12)?,
                created_on: row.get(13)?,
                created_by: row.get(14)?,
                is_visible: row.get::<_, i32>(15)? != 0,
                zone: row.get(16)?,
                is_zonal_exit: row.get::<_, i32>(17)? != 0,
                zonal_neighbour: row.get(18)?,
                kmz_lib_no: row.get(19)?,
                country: row.get(20)?,
                is_capacity_allow: row.get::<_, i32>(21)? != 0,
                err_code: row.get(22)?,
                room: row.get(23)?,
                floor: row.get(24)?,
                is_10g_site: row.get::<_, i32>(25)? != 0,
                is_bypass_site: row.get::<_, i32>(26)? != 0,
                tid_id: row.get(27)?,
                arch_type: row.get(28)?,
                platform: row.get(29)?,
                network: row.get(30)?,
                latitude: row.get(31)?,
                longitude: row.get(32)?,
                geometry_wkt: row.get(33)?,
            })
        })?;
        Ok(rows.collect::<SqliteResult<_>>()?)
    }

    // CRUD Operations for Links
    pub fn insert_link(&self, link: &LinkRecord) -> Result<()> {
        let mut stmt = self.connection.prepare(
            "INSERT OR REPLACE INTO links (
                link_id, site_a, site_b, city, distance, platency_t_100, is_active, is_ldn,
                is_metro, is_common_wire, wire_code, xng_wms_id, kmz_lib_no, fiber_owner,
                is_virtual, created_on, created_by, zone, is_subsea_link, zonea, zoneb,
                link_name, country, countrya, countryb, m_latency, err_code, is_visible,
                link_type, is_capacityavailable, fao, physical_path, platform, network,
                interconnect_links
            ) VALUES (
                ?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11, ?12, ?13, ?14, ?15, ?16,
                ?17, ?18, ?19, ?20, ?21, ?22, ?23, ?24, ?25, ?26, ?27, ?28, ?29, ?30,
                ?31, ?32, ?33, ?34, ?35
            )",
        )?;

        stmt.execute(params![
            link.link_id,
            link.site_a,
            link.site_b,
            link.city,
            link.distance,
            link.platency_t_100,
            link.is_active,
            link.is_ldn,
            link.is_metro,
            link.is_common_wire,
            link.wire_code,
            link.xng_wms_id,
            link.kmz_lib_no,
            link.fiber_owner,
            link.is_virtual,
            link.created_on,
            link.created_by,
            link.zone,
            link.is_subsea_link,
            link.zonea,
            link.zoneb,
            link.link_name,
            link.country,
            link.countrya,
            link.countryb,
            link.m_latency,
            link.err_code,
            link.is_visible,
            link.link_type,
            link.is_capacityavailable,
            link.fao,
            link.physical_path,
            link.platform,
            link.network,
            link.interconnect_links,
        ])?;

        // Update geometry from WKT if provided
        if let Some(ref wkt) = link.geometry_wkt {
            self.connection.execute(
                "UPDATE links SET geom = GeomFromText(?1, 4326) WHERE link_id = ?2",
                params![wkt, link.link_id],
            )?;
        }

        Ok(())
    }

    pub fn get_all_links(&self) -> Result<Vec<LinkRecord>> {
        let mut stmt = self.connection.prepare(
            "SELECT link_id, site_a, site_b, city, distance, platency_t_100, is_active, is_ldn,
             is_metro, is_common_wire, wire_code, xng_wms_id, kmz_lib_no, fiber_owner,
             is_virtual, created_on, created_by, zone, is_subsea_link, zonea, zoneb,
             link_name, country, countrya, countryb, m_latency, err_code, is_visible,
             link_type, is_capacityavailable, fao, physical_path, platform, network,
             interconnect_links, AsText(geom) as geometry_wkt
             FROM links ORDER BY link_id",
        )?;

        let rows = stmt.query_map([], |row| {
            Ok(LinkRecord {
                link_id: row.get(0)?,
                site_a: row.get(1)?,
                site_b: row.get(2)?,
                city: row.get(3)?,
                distance: row.get::<_, Option<f64>>(4)?.unwrap_or(0.0),
                platency_t_100: row.get(5)?,
                is_active: row.get::<_, i32>(6)? != 0,
                is_ldn: row.get::<_, i32>(7)? != 0,
                is_metro: row.get::<_, i32>(8)? != 0,
                is_common_wire: row.get::<_, i32>(9)? != 0,
                wire_code: row.get(10)?,
                xng_wms_id: row.get(11)?,
                kmz_lib_no: row.get(12)?,
                fiber_owner: row.get(13)?,
                is_virtual: row.get::<_, i32>(14)? != 0,
                created_on: row.get(15)?,
                created_by: row.get(16)?,
                zone: row.get(17)?,
                is_subsea_link: row.get::<_, i32>(18)? != 0,
                zonea: row.get(19)?,
                zoneb: row.get(20)?,
                link_name: row.get(21)?,
                country: row.get(22)?,
                countrya: row.get(23)?,
                countryb: row.get(24)?,
                m_latency: row.get(25)?,
                err_code: row.get(26)?,
                is_visible: row.get::<_, i32>(27)? != 0,
                link_type: row.get(28)?,
                is_capacityavailable: row.get::<_, i32>(29)? != 0,
                fao: row.get(30)?,
                physical_path: row.get(31)?,
                platform: row.get(32)?,
                network: row.get(33)?,
                interconnect_links: row.get(34)?,
                geometry_wkt: row.get(35)?,
            })
        })?;
        Ok(rows.collect::<SqliteResult<_>>()?)
    }

    pub fn insert_kml(&self, record: &KmlRecord) -> Result<()> {
        self.connection
            .execute(
                "INSERT INTO kmls (lib_no, geometry_type, geom)
         VALUES (?1, ?2, ST_GeomFromText(?3, 4326))",
                params![record.lib_no, record.geometry_type, record.wkt],
            )
            .context("Failed to insert KML record")?;
        Ok(())
    }

    pub fn insert_kml_bulk(&mut self, records: &[KmlRecord]) -> Result<()> {
        let tx = self.connection.transaction()?;
        {
            let mut stmt = tx.prepare(
                "INSERT INTO kmls (lib_no, geometry_type, geom)
             VALUES (?1, ?2, ST_GeomFromText(?3, 4326))",
            )?;
            for rec in records {
                stmt.execute(params![rec.lib_no, rec.geometry_type, rec.wkt])?;
            }
        }
        tx.commit()?;
        Ok(())
    }
    pub fn get_kml_in_bbox(
        &self,
        min_x: f64,
        min_y: f64,
        max_x: f64,
        max_y: f64,
    ) -> Result<Vec<KmlRecord>> {
        let mut stmt = self.connection.prepare(
            "SELECT lib_no, geometry_type, AsText(geom) as wkt
         FROM kmls
         WHERE MBRIntersects(geom, BuildMbr(?1, ?2, ?3, ?4))",
        )?;

        let rows = stmt.query_map(params![min_x, min_y, max_x, max_y], |row| {
            Ok(KmlRecord {
                lib_no: row.get(0)?,
                geometry_type: row.get(1)?,
                wkt: row.get(2)?,
            })
        })?;

        Ok(rows.filter_map(Result::ok).collect())
    }

    // Analytics methods
    pub fn get_analytics(&self) -> Result<AnalyticsResult> {
        let total_sites: i64 = self.connection.query_row(
            "SELECT COUNT(*) FROM sites WHERE is_active = 1",
            [],
            |row| row.get(0),
        )?;
        let total_links: i64 = self.connection.query_row(
            "SELECT COUNT(*) FROM links WHERE is_active = 1",
            [],
            |row| row.get(0),
        )?;

        let mut countries = Vec::new();
        let mut stmt = self.connection.prepare(
            "SELECT DISTINCT country FROM sites WHERE country IS NOT NULL ORDER BY country",
        )?;
        let rows = stmt.query_map([], |row| Ok(row.get::<_, String>(0)?))?;
        for row in rows {
            countries.push(row?);
        }

        let mut cities = Vec::new();
        let mut stmt = self
            .connection
            .prepare("SELECT DISTINCT city FROM sites WHERE city IS NOT NULL ORDER BY city")?;
        let rows = stmt.query_map([], |row| Ok(row.get::<_, String>(0)?))?;
        for row in rows {
            cities.push(row?);
        }

        let mut platforms = Vec::new();
        let mut stmt = self.connection.prepare(
            "SELECT DISTINCT platform FROM sites WHERE platform IS NOT NULL ORDER BY platform",
        )?;
        let rows = stmt.query_map([], |row| Ok(row.get::<_, String>(0)?))?;
        for row in rows {
            platforms.push(row?);
        }

        let mut networks = Vec::new();
        let mut stmt = self.connection.prepare(
            "SELECT DISTINCT network FROM sites WHERE network IS NOT NULL ORDER BY network",
        )?;
        let rows = stmt.query_map([], |row| Ok(row.get::<_, String>(0)?))?;
        for row in rows {
            networks.push(row?);
        }

        let mut site_types = Vec::new();
        let mut stmt = self.connection.prepare("SELECT platform, COUNT(*) FROM sites WHERE platform IS NOT NULL GROUP BY platform ORDER BY COUNT(*) DESC")?;
        let rows = stmt.query_map([], |row| {
            Ok((row.get::<_, String>(0)?, row.get::<_, i64>(1)?))
        })?;
        for row in rows {
            site_types.push(row?);
        }

        let mut link_types = Vec::new();
        let mut stmt = self.connection.prepare("SELECT link_type, COUNT(*) FROM links WHERE link_type IS NOT NULL GROUP BY link_type ORDER BY COUNT(*) DESC")?;
        let rows = stmt.query_map([], |row| {
            Ok((row.get::<_, String>(0)?, row.get::<_, i64>(1)?))
        })?;
        for row in rows {
            link_types.push(row?);
        }

        let avg_distance: f64 = self
            .connection
            .query_row(
                "SELECT AVG(distance) FROM links WHERE distance > 0",
                [],
                |row| row.get(0),
            )
            .unwrap_or(0.0);
        let max_distance: f64 = self
            .connection
            .query_row(
                "SELECT MAX(distance) FROM links WHERE distance > 0",
                [],
                |row| row.get(0),
            )
            .unwrap_or(0.0);
        let min_distance: f64 = self
            .connection
            .query_row(
                "SELECT MIN(distance) FROM links WHERE distance > 0",
                [],
                |row| row.get(0),
            )
            .unwrap_or(0.0);

        Ok(AnalyticsResult {
            total_sites,
            total_links,
            countries,
            cities,
            platforms,
            networks,
            site_types,
            link_types,
            avg_distance,
            max_distance,
            min_distance,
        })
    }

    // Pathfinding methods
    pub fn find_shortest_path(&self, source: &str, destination: &str) -> Result<PathResult> {
        // Simple implementation using BFS for now
        // In production, implement Dijkstra's algorithm
        let sites = self.get_all_sites()?;
        let links = self.get_all_links()?;

        // Build adjacency list
        use std::collections::{HashMap, VecDeque};
        let mut graph: HashMap<String, Vec<(String, f64)>> = HashMap::new();

        for link in &links {
            if !link.is_active {
                continue;
            }

            graph
                .entry(link.site_a.clone())
                .or_insert_with(Vec::new)
                .push((link.site_b.clone(), link.distance));

            graph
                .entry(link.site_b.clone())
                .or_insert_with(Vec::new)
                .push((link.site_a.clone(), link.distance));
        }

        // BFS to find path
        let mut queue = VecDeque::new();
        let mut visited = HashMap::new();
        let mut parent = HashMap::new();

        queue.push_back(source.to_string());
        visited.insert(source.to_string(), true);

        while let Some(current) = queue.pop_front() {
            if current == destination {
                break;
            }

            if let Some(neighbors) = graph.get(&current) {
                for (neighbor, _distance) in neighbors {
                    if !visited.contains_key(neighbor) {
                        visited.insert(neighbor.clone(), true);
                        parent.insert(neighbor.clone(), current.clone());
                        queue.push_back(neighbor.clone());
                    }
                }
            }
        }

        // Reconstruct path
        let mut path = Vec::new();
        let mut current = destination.to_string();
        path.push(current.clone());

        while let Some(prev) = parent.get(&current) {
            path.push(prev.clone());
            current = prev.clone();
        }

        path.reverse();

        if path.is_empty() || path.first() != Some(&source.to_string()) {
            anyhow::bail!("No path found from {} to {}", source, destination);
        }

        // Calculate total distance and collect path data
        let mut total_distance = 0.0;
        let mut total_latency = 0.0;
        let mut path_links = Vec::new();
        let mut path_sites = Vec::new();

        // Get sites in path
        for site_id in &path {
            if let Some(site) = sites.iter().find(|s| &s.site_id == site_id) {
                path_sites.push(site.clone());
            }
        }

        // Get links in path
        for i in 0..path.len() - 1 {
            let from = &path[i];
            let to = &path[i + 1];

            if let Some(link) = links.iter().find(|l| {
                (l.site_a == *from && l.site_b == *to) || (l.site_a == *to && l.site_b == *from)
            }) {
                total_distance += link.distance;
                if let Some(latency) = link.m_latency {
                    total_latency += latency;
                }
                path_links.push(link.clone());
            }
        }

        Ok(PathResult {
            path,
            total_distance,
            total_latency,
            hop_count: path_sites.len() as i32 - 1,
            sites: path_sites,
            links: path_links,
        })
    }

    pub fn get_database_info(&self) -> DatabaseInfo {
        let site_count: i64 = self
            .connection
            .query_row("SELECT COUNT(*) FROM sites", [], |row| row.get(0))
            .unwrap_or(0);
        let link_count: i64 = self
            .connection
            .query_row("SELECT COUNT(*) FROM links", [], |row| row.get(0))
            .unwrap_or(0);

        DatabaseInfo {
            name: self.name.clone(),
            site_count,
            link_count,
            created_at: chrono::Utc::now().to_rfc3339(),
            size_bytes: 0, // Would need OS-specific code to get actual file size
        }
    }
}
