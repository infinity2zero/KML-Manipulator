// //main.rs
// #![cfg_attr(
//     all(not(debug_assertions), target_os = "windows"),
//     windows_subsystem = "windows"
// )]

// mod commands;
// mod spatial_db;

// use std::collections::HashMap;

// use tauri::Manager;
// use tauri::Size;

// use commands::DatabaseManager;

// use tauri_plugin_opener::init as init_opener;
// use tauri_plugin_os::init as init_os;

// use tauri::{
//   menu::{Menu, MenuItem},
//   tray::TrayIconBuilder,
//   AppHandle,
// };

// fn build_tray(app: &AppHandle) -> tauri::Result<()> {
//   // Menu items
//   let show = MenuItem::with_id(app, "show", "Show", true, None::<&str>)?;
//   let hide = MenuItem::with_id(app, "hide", "Hide", true, None::<&str>)?;
//   let toggle = MenuItem::with_id(app, "toggle", "Toggle Visibility", true, None::<&str>)?;
//   let quit = MenuItem::with_id(app, "quit", "Quit", true, None::<&str>)?;

//   // Menu
//   let menu = Menu::with_items(app, &[&show, &hide, &toggle, &quit])?;

//   // Tray icon
//   TrayIconBuilder::new()
//     .icon(app.default_window_icon().unwrap().clone()) // or your own icon
//     .menu(&menu)
//     .menu_on_left_click(true)
//     .on_menu_event(|app, event| {
//       if let Some(window) = app.get_webview_window("main") {
//         match event.id.as_ref() {
//           "show" => { let _ = window.show(); let _ = window.set_focus(); }
//           "hide" => { let _ = window.hide(); }
//           "toggle" => {
//             if window.is_visible().unwrap_or(true) {
//               let _ = window.hide();
//             } else {
//               let _ = window.show();
//               let _ = window.set_focus();
//             }
//           }
//           "quit" => app.exit(0),
//           _ => {}
//         }
//       }
//     })
//     .build(app)?;

//   Ok(())
// }

// fn main() {
//   println!("🚀 ISP Route — Tauri + SpatiaLite");

//   tauri::Builder::default()
//     .setup(|app| {
//       // window min size
//       let window = app.get_webview_window("main").unwrap();
//       window.set_min_size(Some(Size::Logical(tauri::LogicalSize {
//         width: 800.0,
//         height: 600.0,
//       })))?;

//       // FIX: pass an AppHandle to the tray builder
//       let handle = app.handle();
//       build_tray(&handle)?;

//       Ok(())
//     })
//     // plugins
//     .plugin(init_opener())
//     .plugin(init_os())
//     .plugin(tauri_plugin_global_shortcut::Builder::new().build())
//     // state
//     .manage(DatabaseManager::new(HashMap::new()))
//     // commands
//     .invoke_handler(tauri::generate_handler![
//     //   commands::comprehensive_spatial_test,
//     //   commands::test_spatial_operations,
//     //   commands::create_database_from_test_data,
//       commands::get_all_sites,
//       commands::get_all_links,
//     //   commands::get_sites_near
//     ])
//     .run(tauri::generate_context!())
//     .expect("error while running tauri application");
// }

// src-tauri/src/main.rs
// #![cfg_attr(
//     all(not(debug_assertions), target_os = "windows"),
//     windows_subsystem = "windows"
// )]

// mod commands;
// mod spatial_db;
// mod kml_processor; // Add this line


// use std::collections::HashMap;
// use tauri::Manager;
// use tauri::Size;
// use commands::DatabaseManager;

// use tauri_plugin_opener::init as init_opener;
// use tauri_plugin_os::init as init_os;

// use tauri::{
//   menu::{Menu, MenuItem},
//   tray::TrayIconBuilder,
//   AppHandle,
// };

// fn build_tray(app: &AppHandle) -> tauri::Result<()> {
//   let show = MenuItem::with_id(app, "show", "Show", true, None::<&str>)?;
//   let hide = MenuItem::with_id(app, "hide", "Hide", true, None::<&str>)?;
//   let toggle = MenuItem::with_id(app, "toggle", "Toggle Visibility", true, None::<&str>)?;
//   let quit = MenuItem::with_id(app, "quit", "Quit", true, None::<&str>)?;

//   let menu = Menu::with_items(app, &[&show, &hide, &toggle, &quit])?;

//   TrayIconBuilder::new()
//     .icon(app.default_window_icon().unwrap().clone())
//     .menu(&menu)
//     .show_menu_on_left_click(true)
//     .on_menu_event(|app, event| {
//       if let Some(window) = app.get_webview_window("main") {
//         match event.id.as_ref() {
//           "show" => { let _ = window.show(); let _ = window.set_focus(); }
//           "hide" => { let _ = window.hide(); }
//           "toggle" => {
//             if window.is_visible().unwrap_or(true) {
//               let _ = window.hide();
//             } else {
//               let _ = window.show();
//               let _ = window.set_focus();
//             }
//           }
//           "quit" => app.exit(0),
//           _ => {}
//         }
//       }
//     })
//     .build(app)?;

//   Ok(())
// }

// fn main() {
//   println!("🚀 ISP Route — Tauri v2 + Angular + SpatiaLite");

//   tauri::Builder::default()
//     .setup(|app| {
//       let window = app.get_webview_window("main").unwrap();
//       window.set_min_size(Some(Size::Logical(tauri::LogicalSize {
//         width: 1200.0,
//         height: 800.0,
//       })))?;

//       let handle = app.handle();
//       build_tray(&handle)?;

//       Ok(())
//     })
//     .plugin(init_opener())
//     .plugin(init_os())
//     .plugin(tauri_plugin_global_shortcut::Builder::new().build())
//     .manage(DatabaseManager::new(HashMap::new()))
//     .invoke_handler(tauri::generate_handler![
//       // Database management
//       commands::create_database,
//       commands::list_databases,
//       commands::delete_database,
//       // commands::create_persistent_database,
      
//       // Data operations
//       commands::import_data,
//       commands::get_all_sites,
//       commands::get_all_links,
//       commands::update_site,
//       commands::update_link,
      
//       // Analytics
//       commands::get_analytics,
      
//       // Pathfinding
//       commands::find_shortest_path,
      
//       // PBF tiles for MapLibre
//       commands::get_sites_pbf,
//       commands::get_links_pbf,
      
//       // Testing/utilities
//       // commands::comprehensive_spatial_test,
//       // commands::test_spatial_operations,
//       // commands::test_resource_resolution,
//     ])
//     .run(tauri::generate_context!())
//     .expect("error while running tauri application");
// }



//--v3 with crabnebul---

// #![cfg_attr(
//     all(not(debug_assertions), target_os = "windows"),
//     windows_subsystem = "windows"
// )]

// mod commands;
// mod spatial_db;
// mod kml_processor; // Add this line

// use std::collections::HashMap;
// use tauri::Manager;
// use tauri::Size;
// use commands::DatabaseManager;

// use tauri_plugin_opener::init as init_opener;
// use tauri_plugin_os::init as init_os;

// use tauri::{
//     menu::{Menu, MenuItem},
//     tray::TrayIconBuilder,
//     AppHandle,
// };

// fn build_tray(app: &AppHandle) -> tauri::Result<()> {
//     let show = MenuItem::with_id(app, "show", "Show", true, None::<&str>)?;
//     let hide = MenuItem::with_id(app, "hide", "Hide", true, None::<&str>)?;
//     let toggle = MenuItem::with_id(app, "toggle", "Toggle Visibility", true, None::<&str>)?;
//     let quit = MenuItem::with_id(app, "quit", "Quit", true, None::<&str>)?;

//     let menu = Menu::with_items(app, &[&show, &hide, &toggle, &quit])?;

//     TrayIconBuilder::new()
//         .icon(app.default_window_icon().unwrap().clone())
//         .menu(&menu)
//         .show_menu_on_left_click(true)
//         .on_menu_event(|app, event| {
//             if let Some(window) = app.get_webview_window("main") {
//                 match event.id.as_ref() {
//                     "show" => {
//                         let _ = window.show();
//                         let _ = window.set_focus();
//                     }
//                     "hide" => {
//                         let _ = window.hide();
//                     }
//                     "toggle" => {
//                         if window.is_visible().unwrap_or(true) {
//                             let _ = window.hide();
//                         } else {
//                             let _ = window.show();
//                             let _ = window.set_focus();
//                         }
//                     }
//                     "quit" => app.exit(0),
//                     _ => {}
//                 }
//             }
//         })
//         .build(app)?;

//     Ok(())
// }

// fn main() {
//     println!("🚀 ISP Route — Tauri v2 + Angular + SpatiaLite");

//     // Initialize the devtools plugin early, only in dev builds
//     #[cfg(debug_assertions)]
//     let devtools = tauri_plugin_devtools::init();

//     let mut builder = tauri::Builder::default()
//         .setup(|app| {
//             let window = app.get_webview_window("main").unwrap();
//             window.set_min_size(Some(Size::Logical(tauri::LogicalSize {
//                 width: 1200.0,
//                 height: 800.0,
//             })))?;

//             let handle = app.handle();
//             build_tray(&handle)?;

//             Ok(())
//         })
//         .plugin(init_opener())
//         .plugin(init_os())
//         .plugin(tauri_plugin_global_shortcut::Builder::new().build())
//         .manage(DatabaseManager::new(HashMap::new()))
//         .invoke_handler(tauri::generate_handler![
//             // Database management
//             commands::create_database,
//             commands::list_databases,
//             commands::delete_database,
//             // commands::create_persistent_database,

//             // Data operations
//             commands::import_data,
//             commands::get_all_sites,
//             commands::get_all_links,
//             commands::update_site,
//             commands::update_link,

//             // Analytics
//             commands::get_analytics,

//             // Pathfinding
//             commands::find_shortest_path,

//             // PBF tiles for MapLibre
//             commands::get_sites_pbf,
//             commands::get_links_pbf,
//         ]);

//     #[cfg(debug_assertions)]
//     {
//         builder = builder.plugin(devtools);
//     }

//     builder
//         .run(tauri::generate_context!())
//         .expect("error while running tauri application");
// }



//V4--
// src-tauri/src/main.rs
// src-tauri/src/main.rs
// #![cfg_attr(
//     all(not(debug_assertions), target_os = "windows"),
//     windows_subsystem = "windows"
// )]

// mod commands;
// mod spatial_db;
// // mod kml::kml_processor;
// pub mod kml;

// use std::collections::HashMap;
// use tauri::Manager;
// use tauri::Size;
// use commands::DatabaseManager;
// use std::sync::{Arc, Mutex};

// use tauri_plugin_opener::init as init_opener;
// use tauri_plugin_os::init as init_os;
// use tauri_plugin_dialog;


// use tauri::{
//     menu::{Menu, MenuItem},
//     tray::TrayIconBuilder,
//     AppHandle,
// };

// use crate::spatial_db::SpatialDatabase;

// fn build_tray(app: &AppHandle) -> tauri::Result<()> {
//     let show = MenuItem::with_id(app, "show", "Show", true, None::<&str>)?;
//     let hide = MenuItem::with_id(app, "hide", "Hide", true, None::<&str>)?;
//     let toggle = MenuItem::with_id(app, "toggle", "Toggle Visibility", true, None::<&str>)?;
//     let quit = MenuItem::with_id(app, "quit", "Quit", true, None::<&str>)?;

//     let menu = Menu::with_items(app, &[&show, &hide, &toggle, &quit])?;

//     TrayIconBuilder::new()
//         .icon(app.default_window_icon().unwrap().clone())
//         .menu(&menu)
//         .show_menu_on_left_click(true)
//         .on_menu_event(|app, event| {
//             if let Some(window) = app.get_webview_window("main") {
//                 match event.id.as_ref() {
//                     "show" => {
//                         let _ = window.show();
//                         let _ = window.set_focus();
//                     }
//                     "hide" => {
//                         let _ = window.hide();
//                     }
//                     "toggle" => {
//                         if window.is_visible().unwrap_or(true) {
//                             let _ = window.hide();
//                         } else {
//                             let _ = window.show();
//                             let _ = window.set_focus();
//                         }
//                     }
//                     "quit" => app.exit(0),
//                     _ => {}
//                 }
//             }
//         })
//         .build(app)?;

//     Ok(())
// }

// fn setup_logging() {
//     // Only setup logging if devtools is NOT enabled
//     #[cfg(not(debug_assertions))]
//     {
//         // Production mode - minimal logging
//         env_logger::Builder::from_default_env()
//             .filter_level(log::LevelFilter::Info)
//             .format_timestamp_secs()
//             .init();
        
//         log::info!("📦 Production logging enabled");
//     }
    
//     // In debug mode, let devtools handle logging
//     #[cfg(debug_assertions)]
//     {
//         // Try to initialize logging, but don't panic if devtools already did
//         let _ = env_logger::Builder::from_default_env()
//             .filter_level(log::LevelFilter::Debug)
//             .format_timestamp_secs()
//             .try_init();
        
//         // This will either succeed or fail silently if devtools initialized first
//         println!("🔧 Debug mode - logging handled by devtools or env_logger");
//     }
// }

// fn main() {
//     println!("🚀 ISP Route — Tauri v2 + Angular + SpatiaLite starting...");

//     // Initialize the devtools plugin early, only in dev builds
//     #[cfg(debug_assertions)]
//     let devtools = tauri_plugin_devtools::init();

//     let mut builder = tauri::Builder::default()
//         .setup(|app| {
//             // Setup logging AFTER devtools is initialized
//             setup_logging();
            
//             println!("🏗️ Setting up application...");
            
//             let window = app.get_webview_window("main").unwrap();
//             window.set_min_size(Some(Size::Logical(tauri::LogicalSize {
//                 width: 1200.0,
//                 height: 800.0,
//             })))?;

//             let handle = app.handle();
//             build_tray(&handle)?;

//             println!("✅ Application setup complete");
//             Ok(())
//         })
//         .plugin(init_opener())
//         .plugin(init_os())
//         .plugin(tauri_plugin_dialog::init())
//         .plugin(tauri_plugin_global_shortcut::Builder::new().build())
// .manage(Arc::new(Mutex::new(HashMap::<String, SpatialDatabase>::new())))

//         .invoke_handler(tauri::generate_handler![
//             // Database management
//             commands::create_database,
//             commands::list_databases,
//             commands::delete_database,
//             commands::load_database,
//             commands::get_database_info,

//             // Data operations
//             commands::import_data,
//             commands::get_all_sites,
//             commands::get_all_links,
//             commands::update_site,
//             commands::update_link,
//             // commands::import_raw_data,
//             commands::import_from_files, // ADD THIS NEW COMMAND



//             // Analytics
//             commands::get_analytics,

//             // Pathfinding
//             commands::find_shortest_path,

//             // PBF tiles for MapLibre
//             commands::get_sites_pbf,
//             commands::get_links_pbf,
//         ]);

//     #[cfg(debug_assertions)]
//     {
//         builder = builder.plugin(devtools);
//         println!("🔧 Devtools plugin loaded");
//     }

//     println!("🏃 Starting Tauri application...");
//     builder
//         .run(tauri::generate_context!())
//         .expect("error while running tauri application");
// }


//! ISP Route - Tauri v2 + Angular + SpatiaLite Application
//! 
//! A cross-platform desktop application for ISP network routing and geospatial data management.

#![cfg_attr(
    all(not(debug_assertions), target_os = "windows"),
    windows_subsystem = "windows"
)]

mod commands;
mod spatial_db;
pub mod kml;

use std::collections::HashMap;
use std::sync::{Arc, Mutex};
use tauri::{Manager, Size};
use commands::DatabaseManager;

// Plugin imports
use tauri_plugin_opener::init as init_opener;
use tauri_plugin_os::init as init_os;
use tauri_plugin_dialog;

// System tray imports
use tauri::{
    menu::{Menu, MenuItem},
    tray::TrayIconBuilder,
    AppHandle,
};

use crate::spatial_db::SpatialDatabase;

/// Builds and configures the system tray
fn build_tray(app: &AppHandle) -> tauri::Result<()> {
    let show = MenuItem::with_id(app, "show", "Show", true, None::<&str>)?;
    let hide = MenuItem::with_id(app, "hide", "Hide", true, None::<&str>)?;
    let toggle = MenuItem::with_id(app, "toggle", "Toggle Visibility", true, None::<&str>)?;
    let quit = MenuItem::with_id(app, "quit", "Quit", true, None::<&str>)?;

    let menu = Menu::with_items(app, &[&show, &hide, &toggle, &quit])?;

    TrayIconBuilder::new()
        .icon(app.default_window_icon().unwrap().clone())
        .menu(&menu)
        .show_menu_on_left_click(true)
        .on_menu_event(|app, event| {
            if let Some(window) = app.get_webview_window("main") {
                match event.id.as_ref() {
                    "show" => {
                        let _ = window.show();
                        let _ = window.set_focus();
                    }
                    "hide" => {
                        let _ = window.hide();
                    }
                    "toggle" => {
                        if window.is_visible().unwrap_or(true) {
                            let _ = window.hide();
                        } else {
                            let _ = window.show();
                            let _ = window.set_focus();
                        }
                    }
                    "quit" => app.exit(0),
                    _ => {}
                }
            }
        })
        .build(app)?;

    Ok(())
}

/// Sets up logging configuration based on build mode
fn setup_logging() {
    #[cfg(not(debug_assertions))]
    {
        // Production mode - structured logging with appropriate levels
        env_logger::Builder::from_default_env()
            .filter_level(log::LevelFilter::Info)
            .format_timestamp_secs()
            .format_target(false)
            .format_module_path(false)
            .init();
        
        log::info!("📦 Production logging initialized");
    }
    
    #[cfg(debug_assertions)]
    {
        // Debug mode - more verbose logging
        let _ = env_logger::Builder::from_default_env()
            .filter_level(log::LevelFilter::Debug)
            .format_timestamp_secs()
            .format_target(true)
            .format_module_path(true)
            .try_init();
        
        println!("🔧 Debug mode logging initialized");
    }
}

fn main() {
    println!("🚀 ISP Route — Tauri v2 + Angular + SpatiaLite starting...");

    // Initialize devtools in debug builds only
    #[cfg(debug_assertions)]
    let devtools = tauri_plugin_devtools::init();

    let mut builder = tauri::Builder::default()
        .setup(|app| {
            // Setup logging after app initialization
            setup_logging();
            
            log::info!("🏗️ Setting up application...");
            
            // Configure main window
            if let Some(window) = app.get_webview_window("main") {
                window.set_min_size(Some(Size::Logical(tauri::LogicalSize {
                    width: 1200.0,
                    height: 800.0,
                })))?;
                log::debug!("Window size constraints applied");
            }

            // Setup system tray
            let handle = app.handle();
            build_tray(&handle)?;
            log::debug!("System tray configured");

            log::info!("✅ Application setup complete");
            Ok(())
        })
        // Register plugins
        .plugin(init_opener())
        .plugin(init_os())
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_global_shortcut::Builder::new().build())
        // Manage shared database state
        .manage(Arc::new(Mutex::new(HashMap::<String, SpatialDatabase>::new())) as DatabaseManager)
        // Register command handlers
        .invoke_handler(tauri::generate_handler![
            // Database lifecycle management
            commands::create_database,
            commands::list_databases,
            commands::delete_database,
            commands::load_database,
            commands::get_database_info,

            // Data import operations
            commands::import_data,
            commands::import_from_files,

            // CRUD operations
            commands::get_all_sites,
            commands::get_all_links,
            commands::update_site,
            commands::update_link,

            // Analytics and pathfinding
            commands::get_analytics,
            commands::find_shortest_path,

            // PBF tile generation for MapLibre
            commands::get_sites_pbf,
            commands::get_links_pbf,
        ]);

    // Add devtools in debug mode
    #[cfg(debug_assertions)]
    {
        builder = builder.plugin(devtools);
        println!("🔧 Devtools plugin loaded");
    }

    log::info!("🏃 Starting Tauri application...");
    
    // Run the application
    builder
        .run(tauri::generate_context!())
        .expect("Failed to run Tauri application");
}